# Grade 3 Pyramedic Curriculum - Month 1
## Two 5-Day Learning Cycles

### Overview
- **Schedule**: Tuesdays & Thursdays, 45-minute sessions
- **Cycles**: Mesopotamia (Week 1-2) and Egypt (Week 3-4)
- **Framework**: Myth → Art → Math → Problem → Solution

---

## CYCLE 1: MESOPOTAMIA (The Land Between Rivers)

### Day 1 (Tuesday, Week 1): MYTH - The Epic of Gilgamesh
**Learning Objectives:**
- Understand the concept of opposing truths
- Explore flood myths as both destructive and creative forces
- Develop perspective-taking skills (SEL)

**Activities:**
- Story circle: Read adapted Gilgamesh excerpt
- Create story maps showing opposites
- Discussion: "Can two opposite things both be true?"

**Materials Needed:**
- Gilgamesh story cards
- Story map templates
- Opposing concepts visual aids

### Day 2 (Tuesday, Week 1): ART - Cylinder Seals
**Learning Objectives:**
- Design patterns showing opposing concepts
- Understand repetition and rhythm in art
- Express beliefs through symbols

**Activities:**
- Create personal cylinder seals in clay
- Include symbols of opposites (sun/moon, water/fire)
- Roll patterns to see unified designs

**Materials:**
- Air-dry clay
- Rolling pins
- Pattern stamps

### Day 3 (Tuesday, Week 1): MATH - Base-60 System
**Learning Objectives:**
- Explore why Mesopotamians used base-60
- Understand factors and divisibility
- Connect ancient math to modern time-keeping

**Activities:**
- Factor rainbow for 60
- Clock exploration (60 minutes, 60 seconds)
- Sacred numbers activity (3 and 4)

**Assessment:**
- Can identify at least 6 factors of 60
- Explains one modern use of base-60

### Day 4 (Thursday, Week 2): PROBLEM - The Both-Box Challenge
**Learning Objectives:**
- Apply dialectical thinking
- Collaborate in teams
- Solve real-world problems using opposing forces

**Activities:**
- Teams create "Both-Boxes" with opposite items that work together
- Examples: rules/freedom, noise/quiet, work/play
- Present solutions to class

**SEL Focus:** 
- Collaboration
- Conflict resolution
- Creative problem-solving

### Day 5 (Thursday, Week 2): SOLUTION - Synthesis & Revelation
**Learning Objectives:**
- Synthesize week's learning
- Recognize "both/and" thinking in daily life
- Bridge to next civilization

**Activities:**
- Both-Box presentations
- Modern examples (batteries, magnets)
- Celebration of discoveries
- Preview: "How did Egyptians find patterns in nature?"

**Breakthrough Moment:**
Students realize opposing forces create energy and innovation

---

## CYCLE 2: ANCIENT EGYPT (Gift of the Nile)

### Day 1 (Tuesday, Week 3): MYTH - Ra and Osiris
**Learning Objectives:**
- Recognize patterns in Egyptian mythology
- Understand cyclical thinking
- Connect myths to natural phenomena

**Activities:**
- Ra's sun boat journey activity
- Osiris and seasons connection
- Create personal sun boat maps

**Cultural Connection:**
- Day/night cycle
- Seasonal patterns
- Life/death/rebirth

### Day 2 (Tuesday, Week 3): ART - Hieroglyphics
**Learning Objectives:**
- Learn basic hieroglyphic symbols
- Create patterns for communication
- Design personal cartouches

**Activities:**
- Learn 10 hieroglyphic symbols
- Write names in cartouches
- Create class hieroglyphic dictionary

**Materials:**
- Papyrus paper (or brown paper)
- Hieroglyphic charts
- Gold markers

### Day 3 (Tuesday, Week 3): MATH - Pyramid Geometry
**Learning Objectives:**
- Explore triangles as strongest shapes
- Understand unit fractions (1/n)
- Discover the 3-4-5 triangle

**Activities:**
- Build pyramids with blocks
- Unit fraction puzzles
- Measure and create 3-4-5 triangles

**Mathematical Concepts:**
- Triangle stability
- Egyptian fractions
- Sacred geometry

### Day 4 (Thursday, Week 4): PROBLEM - Nile Flooding Predictor
**Learning Objectives:**
- Use patterns to make predictions
- Apply mathematical thinking to real problems
- Work with data and charts

**Activities:**
- Analyze flood pattern charts
- Create flood warning calendars
- Divide land fairly using unit fractions

**Critical Thinking:**
- Pattern recognition
- Data analysis
- Fair distribution

### Day 5 (Thursday, Week 4): SOLUTION - Pattern Power
**Learning Objectives:**
- Compare Mesopotamian and Egyptian thinking
- Synthesize both civilizations' wisdom
- Celebrate learning journey

**Activities:**
- Present flood predictions
- Create comparison charts
- Design class museum display
- Award ceremony for pattern detectives

**Culminating Understanding:**
Both opposite-thinking and pattern-thinking solve problems!

---

## Assessment & Family Extensions

### Skills Developed:
- **Mathematical**: Factors, fractions, patterns, geometry
- **Artistic**: Symbol creation, pattern design, cultural expression
- **SEL**: Perspective-taking, collaboration, synthesis
- **Problem-Solving**: Dialectical thinking, pattern recognition

### Family Activities:
- Find opposites at home that work together
- Create family hieroglyphic messages
- Explore patterns in nature
- Visit local museums for ancient civilization exhibits

### Standards Alignment:
- Common Core Math: 3.OA, 3.NF, 3.MD
- NGSS: 3-5-ETS1-1 (Engineering Design)
- NCSS: Culture, Time/Continuity/Change
- SEL: CASEL Core Competencies

### Next Month Preview:
Ancient Greece (Olympic mathematics) and China (invention cycles)