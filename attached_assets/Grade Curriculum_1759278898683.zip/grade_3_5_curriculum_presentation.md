# Month-Long Curriculum Presentations: Grades 3, 4, and 5
## Ancient Civilizations Through Pattern, Art, Math & Mythology

---

## GRADE 3 CURRICULUM: FOUNDATIONS OF DISCOVERY
### 2 Five-Day Cycles

### **CYCLE 1: MESOPOTAMIA - WHERE CIVILIZATION BEGAN**
*Week 1: Building Blocks of Society*

#### Day 1 (Monday): MYTH - The Epic of Gilgamesh
- **Morning Circle:** Story of friendship and courage
- **Activities:**
  - Story mapping with visual aids
  - Character emotion wheels
  - Act out key scenes
  - Create friendship symbols
- **SEL Focus:** Social awareness, empathy
- **Materials:** Story props, art supplies, emotion cards

#### Day 2 (Tuesday): ART - Cylinder Seals & Patterns
- **Exploration:** Ancient communication through art
- **Activities:**
  - Design personal cylinder seals
  - Create repeating patterns
  - Roll prints in clay/playdough
  - Gallery walk and pattern hunt
- **Math Integration:** Identify AB, ABC patterns
- **Materials:** Clay, cardboard tubes, stamps

#### Day 3 (Wednesday): MATH - Base-60 Counting System
- **Discovery:** Why 60 minutes? Why 360 degrees?
- **Activities:**
  - Body counting (12 knuckles × 5 fingers)
  - Create clay number tablets
  - Time and angle explorations
  - Math journaling
- **Real-World Connections:** Clocks, circles, calendars
- **Materials:** Clay tablets, protractors, clocks

#### Day 4 (Thursday): PROBLEM - Irrigation Engineering
- **Challenge:** Share water resources fairly
- **Activities:**
  - Team design of water channels
  - Test with actual water
  - Measure and adjust flow
  - Present solutions
- **Collaboration Skills:** Teamwork, communication
- **Materials:** Aluminum pans, tubing, water, cups

#### Day 5 (Friday): REVELATION - The Invention of Writing
- **Breakthrough:** From tokens to cuneiform
- **Activities:**
  - Evolution of symbols timeline
  - Create class dictionary
  - Write secret messages
  - Celebration ceremony
- **Reflection:** How writing changed the world
- **Materials:** Clay, styluses, celebration materials

### **CYCLE 2: ANCIENT EGYPT - PATTERNS IN PYRAMIDS**
*Week 2: Mathematics in Monument*

#### Day 1 (Monday): MYTH - Journey to the Afterlife
- **Morning Circle:** The weighing of the heart
- **Activities:**
  - Create Ma'at's truth feathers
  - Design afterlife journey maps
  - Discuss justice and fairness
  - Egyptian god trading cards
- **SEL Focus:** Responsible decision-making
- **Materials:** Feathers, scales, art supplies

#### Day 2 (Tuesday): ART - Hieroglyphic Cartouches
- **Exploration:** Art as language
- **Activities:**
  - Learn hieroglyphic alphabet
  - Design personal cartouches
  - Paint on "papyrus" (brown paper)
  - Create tomb wall display
- **Cultural Connection:** Names and identity
- **Materials:** Brown paper, paint, hieroglyphic guides

#### Day 3 (Wednesday): MATH - Sacred Geometry
- **Discovery:** The 3-4-5 triangle secret
- **Activities:**
  - Rope geometry (12 knots)
  - Measure with royal cubits
  - Calculate pyramid angles
  - Geometric art patterns
- **Engineering Connection:** Building that lasts
- **Materials:** Rope, measuring tools, graph paper

#### Day 4 (Thursday): PROBLEM - Mummification Science
- **Challenge:** Preserve for eternity
- **Activities:**
  - Research preservation methods
  - Test with fruit samples
  - Observe and record changes
  - Scientific method practice
- **Science Skills:** Hypothesis, observation
- **Materials:** Apples, salt, containers, journals

#### Day 5 (Friday): REVELATION - The Rosetta Stone
- **Breakthrough:** Cracking the code
- **Activities:**
  - Decode hieroglyphic numbers
  - Bilingual message creation
  - Pattern recognition games
  - Discovery celebration
- **Modern Connection:** Computer coding
- **Materials:** Rosetta Stone images, code wheels

---

## GRADE 4 CURRICULUM: EXPANDING HORIZONS
### 2 Five-Day Cycles

### **CYCLE 1: ANCIENT GREECE - LOGIC AND BEAUTY**
*Week 1: The Birth of Mathematical Thinking*

#### Day 1 (Monday): MYTH - The Odyssey Adventures
- **Epic Journey:** Odysseus's challenges
- **Activities:**
  - Map Odysseus's journey
  - Problem-solving scenarios
  - Create hero's journey wheel
  - Character perspective writing
- **SEL Focus:** Perseverance, courage
- **Materials:** Maps, journey wheels, writing materials

#### Day 2 (Tuesday): ART - Greek Pottery & Geometric Design
- **Exploration:** Stories in symmetry
- **Activities:**
  - Study amphora designs
  - Create geometric borders
  - Design narrative pottery
  - Symmetry explorations
- **Math Integration:** Reflection, rotation symmetry
- **Materials:** Clay/paper plates, paints, rulers

#### Day 3 (Wednesday): MATH - Pythagorean Theorem
- **Discovery:** a² + b² = c²
- **Activities:**
  - Proof by paper squares
  - Measure classroom diagonals
  - Create proof artwork
  - Real-world applications
- **Critical Thinking:** Multiple proof methods
- **Materials:** Grid paper, squares, measuring tape

#### Day 4 (Thursday): PROBLEM - Amphitheater Acoustics
- **Challenge:** Design for perfect sound
- **Activities:**
  - Test sound in different shapes
  - Build model amphitheaters
  - Measure sound travel
  - Performance presentations
- **STEM Integration:** Physics of sound
- **Materials:** Cardboard, sound sources, measuring tools

#### Day 5 (Friday): REVELATION - Democratic Voting System
- **Breakthrough:** Power to the people
- **Activities:**
  - Ostraka voting simulation
  - Design fair voting systems
  - Debate current issues
  - Democracy celebration
- **Civic Connection:** Modern democracy
- **Materials:** Pottery shards/paper, voting boxes

### **CYCLE 2: ANCIENT CHINA - HARMONY IN PATTERNS**
*Week 2: Balance and Innovation*

#### Day 1 (Monday): MYTH - The Monkey King's Journey
- **Adventure:** Journey to the West
- **Activities:**
  - Character transformation maps
  - Moral dilemma discussions
  - Create journey scrolls
  - Wisdom collection book
- **SEL Focus:** Self-management, growth mindset
- **Materials:** Scroll paper, art supplies

#### Day 2 (Tuesday): ART - Chinese Calligraphy & Symmetry
- **Exploration:** Art of the brush
- **Activities:**
  - Basic stroke practice
  - Character construction
  - Symmetrical designs
  - Silk painting techniques
- **Cultural Appreciation:** Language as art
- **Materials:** Brushes, ink, rice paper

#### Day 3 (Wednesday): MATH - Tangram Geometry
- **Discovery:** Seven pieces, infinite possibilities
- **Activities:**
  - Create all 13 convex shapes
  - Design challenge cards
  - Area and perimeter puzzles
  - Fraction explorations
- **Spatial Reasoning:** 2D transformation
- **Materials:** Tangram sets, challenge cards

#### Day 4 (Thursday): PROBLEM - Great Wall Logistics
- **Challenge:** Building across mountains
- **Activities:**
  - Calculate materials needed
  - Design efficient transport
  - Test structural strength
  - Cost-benefit analysis
- **Mathematical Modeling:** Scale and proportion
- **Materials:** Building blocks, maps, calculators

#### Day 5 (Friday): REVELATION - Paper & Printing Revolution
- **Breakthrough:** Information for all
- **Activities:**
  - Make recycled paper
  - Create printing blocks
  - Print class newsletter
  - Future of information discussion
- **Modern Connection:** Digital revolution
- **Materials:** Paper pulp, carving blocks, ink

---

## GRADE 5 CURRICULUM: SYNTHESIS AND INNOVATION
### 2 Five-Day Cycles

### **CYCLE 1: ISLAMIC GOLDEN AGE - PATTERN AS MATHEMATICS**
*Week 1: Algorithm and Artistry*

#### Day 1 (Monday): MYTH - One Thousand and One Nights
- **Framework:** Stories within stories
- **Activities:**
  - Nested narrative creation
  - Problem-solving through stories
  - Create story fractals
  - Wisdom anthology
- **SEL Focus:** Creative problem-solving
- **Materials:** Story templates, binding materials

#### Day 2 (Tuesday): ART - Geometric Tessellations
- **Exploration:** Infinite patterns
- **Activities:**
  - Construct Islamic star patterns
  - Design tessellation tiles
  - Create large collaborative mural
  - Explore pattern algorithms
- **Mathematical Precision:** Angle calculations
- **Materials:** Compass, ruler, colored paper

#### Day 3 (Wednesday): MATH - Introduction to Algebra
- **Discovery:** Al-Khwarizmi's gift
- **Activities:**
  - Balance scale equations
  - Variable introduction games
  - Real-world problem solving
  - Create algebra storybooks
- **Abstract Thinking:** From concrete to symbolic
- **Materials:** Balance scales, algebra tiles

#### Day 4 (Thursday): PROBLEM - Astrolabe Navigation
- **Challenge:** Navigate by the stars
- **Activities:**
  - Build working astrolabes
  - Calculate latitude
  - Plan ocean voyages
  - Navigation presentations
- **Integration:** Astronomy, geography, math
- **Materials:** Cardboard, protractors, star charts

#### Day 5 (Friday): REVELATION - The Algorithm Revolution
- **Breakthrough:** Step-by-step thinking
- **Activities:**
  - Create everyday algorithms
  - Program human robots
  - Design decision trees
  - Algorithm celebration
- **Modern Connection:** Computer programming
- **Materials:** Flowchart templates, coding cards

### **CYCLE 2: RENAISSANCE - ART MEETS SCIENCE**
*Week 2: The Marriage of Disciplines*

#### Day 1 (Monday): MYTH - Dante's Mathematical Journey
- **Structure:** Divine Comedy's geometry
- **Activities:**
  - Map the nine circles
  - Create moral mathematics
  - Design personal journeys
  - Philosophical discussions
- **SEL Focus:** Ethical reasoning
- **Materials:** Circle templates, journey maps

#### Day 2 (Tuesday): ART - Linear Perspective Drawing
- **Exploration:** Mathematics of vision
- **Activities:**
  - One-point perspective cities
  - Two-point perspective buildings
  - Vanishing point experiments
  - Gallery exhibition
- **Technical Skill:** Precise measurement
- **Materials:** Rulers, vanishing point tools

#### Day 3 (Wednesday): MATH - The Golden Ratio
- **Discovery:** Mathematics of beauty
- **Activities:**
  - Find phi in nature
  - Fibonacci spiral art
  - Measure facial proportions
  - Design with golden rectangles
- **Pattern Recognition:** Nature's mathematics
- **Materials:** Calipers, spiral templates

#### Day 4 (Thursday): PROBLEM - Dome Engineering Challenge
- **Challenge:** Brunelleschi's puzzle
- **Activities:**
  - Design self-supporting domes
  - Test different materials
  - Calculate stress points
  - Engineering presentations
- **STEAM Integration:** Art, math, engineering
- **Materials:** Various building materials

#### Day 5 (Friday): REVELATION - The Printing Press Changes Everything
- **Breakthrough:** Democratization of knowledge
- **Activities:**
  - Print class books
  - Calculate information spread
  - Design future media
  - Knowledge celebration
- **Future Thinking:** Information age
- **Materials:** Printing supplies, binding materials

---

## ASSESSMENT & DIFFERENTIATION STRATEGIES

### Daily Assessment Tools:
- **Formative:** Exit tickets, observation notes
- **Portfolio:** Daily artifact collection
- **Peer:** Partner feedback forms
- **Self:** Reflection journals

### Differentiation by Grade:
- **Grade 3:** Concrete manipulatives, shorter texts, guided practice
- **Grade 4:** Semi-abstract concepts, independent work time
- **Grade 5:** Abstract thinking, student-led investigations

### Support Structures:
- **Visual:** Picture schedules, anchor charts
- **Kinesthetic:** Movement breaks, hands-on materials
- **Auditory:** Songs, verbal processing time
- **Social:** Flexible grouping, peer tutoring

---

## FAMILY ENGAGEMENT

### Weekly Communications:
- Photo documentation of activities
- Home extension suggestions
- Cultural celebration invitations
- Student showcase preparations

### Home Connections:
- Family cultural artifact sharing
- Parent expertise presentations
- Take-home creation kits
- Digital portfolio access

---

## MATERIALS & RESOURCES

### Basic Kit (All Grades):
- Clay/playdough
- Art supplies
- Measuring tools
- Building materials
- Technology access

### Grade-Specific Additions:
- **Grade 3:** Picture books, simple tools
- **Grade 4:** Chapter books, precision tools
- **Grade 5:** Primary sources, advanced tools

### Digital Resources:
- Virtual museum tours
- Educational videos
- Interactive simulations
- Coding platforms
