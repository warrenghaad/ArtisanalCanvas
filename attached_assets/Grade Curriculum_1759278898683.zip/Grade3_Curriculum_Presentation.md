# GRADE 3: ANCIENT CIVILIZATIONS ADVENTURE
## Month-Long Curriculum | 2 Five-Day Cycles

---

## 🌟 WELCOME TO YOUR TIME TRAVEL ADVENTURE!
### Grade 3 Ancient Civilizations Journey

**Your Mission:**
- 🏛️ Travel through time to discover ancient wisdom
- 🎨 Become mathematicians, artists, and storytellers  
- 🤝 Work together to solve real problems
- ✨ Create your own artifacts and inventions

**Duration:** 20 Days (4 Weeks)
**Ages:** 8-9 years old
**Focus:** Hands-on discovery learning

---

## 📅 WEEK 1: MESOPOTAMIA
### Where Civilization Began

**🗺️ Location:** Between Tigris & Euphrates Rivers
**📅 Time Period:** 3500 BCE
**🏆 Major Achievements:**
- First cities
- Invention of writing
- The wheel
- Mathematics base-60 system

---

## MONDAY - MYTH DAY 📖
### The Epic of Gilgamesh

**Morning Circle (20 min):**
- Meet Gilgamesh and his friend Enkidu
- Discuss: What makes a good friend?

**Activities:**
- 🎭 Act out the story with props
- 🎨 Create character emotion wheels
- 📝 Design friendship symbols
- 🃏 Make character trading cards

**SEL Focus:** Empathy & Social Awareness

---

## TUESDAY - ART DAY 🎨
### Cylinder Seals & Patterns

**Discovery Time:**
- How did ancient people sign their names?
- What stories can patterns tell?

**Create:**
- Design your personal cylinder seal
- Roll prints in clay
- Make repeating patterns
- Share in gallery walk

**Math Connection:** AB, ABC pattern recognition

---

## WEDNESDAY - MATH DAY 🔢
### Base-60 Number System

**Big Question:** Why do we have 60 minutes and 360 degrees?

**Hands-On Math:**
- Count using your body (12 knuckles × 5 fingers = 60!)
- Create clay number tablets
- Solve time puzzles
- Make a Mesopotamian clock

**Real-World:** Connect to modern time & angles

---

## THURSDAY - PROBLEM DAY 🔧
### Irrigation Challenge

**Engineering Challenge:**
Your farms need water! Design a system to share water fairly.

**Team Tasks:**
- Build water channels
- Test with real water
- Measure and adjust flow
- Present your solution

**Skills:** Teamwork, Problem-solving, Communication

---

## FRIDAY - REVELATION DAY 💡
### The Invention of Writing!

**Discovery Celebration:**
- Journey from tokens to cuneiform
- Create class picture dictionary
- Write secret messages
- Decode friend's messages

**Big Reflection:** How did writing change the world?

---

## 📅 WEEK 2: ANCIENT EGYPT
### Patterns in Pyramids

**🗺️ Location:** Along the Nile River
**📅 Time Period:** 3100 BCE
**🏆 Major Achievements:**
- Pyramids
- Hieroglyphics
- Mummification
- Paper (papyrus)

---

## MONDAY - MYTH DAY 📖
### Journey to the Afterlife

**Morning Circle (20 min):**
- The weighing of the heart ceremony
- Discuss: What does it mean to be fair?

**Activities:**
- ⚖️ Create Ma'at's truth feathers
- 🗺️ Design afterlife journey maps
- 👁️ Make Egyptian god masks
- 🎴 Egyptian mythology memory game

**SEL Focus:** Justice & Responsible Decisions

---

## TUESDAY - ART DAY 🎨
### Hieroglyphic Cartouches

**Discovery Time:**
- How can pictures become words?
- What's in a name?

**Create:**
- Learn hieroglyphic alphabet
- Design personal cartouche
- Paint on "papyrus" (brown paper)
- Build class tomb wall

**Cultural Connection:** Identity & Communication

---

## WEDNESDAY - MATH DAY 🔢
### Sacred Geometry

**Big Question:** How did Egyptians build perfect pyramids?

**Hands-On Math:**
- Discover the 3-4-5 triangle
- Measure with rope (12 knots)
- Calculate pyramid angles
- Create geometric art

**Engineering:** Buildings that last 4000 years!

---

## THURSDAY - PROBLEM DAY 🔧
### Mummification Science

**Science Challenge:**
How can we preserve things forever?

**Experiments:**
- Test preservation methods
- Use salt, baking soda on fruit
- Observe and record changes
- Apply scientific method

**Skills:** Hypothesis, Observation, Recording

---

## FRIDAY - REVELATION DAY 💡
### The Rosetta Stone!

**Discovery Celebration:**
- Crack the hieroglyphic code
- Create bilingual messages
- Design code wheels
- Pattern recognition games

**Big Reflection:** How do we unlock ancient secrets?

---

## 🎯 ASSESSMENT STRATEGIES

### Daily Tools:
**Quick Checks:**
- 🎯 Exit tickets (2 min)
- 👀 Observation notes
- 🗂️ Portfolio additions
- 👫 Peer feedback

### Weekly Reviews:
- Student presentations
- Project rubrics
- Growth celebrations
- Parent communications

---

## 🌈 DIFFERENTIATION SUPPORT

### For Different Learners:

**Visual Learners:**
- Picture schedules
- Anchor charts
- Color coding

**Kinesthetic Learners:**
- Movement breaks
- Hands-on materials
- Build and create

**Advanced Students:**
- Extension challenges
- Research projects
- Peer teaching

**Support Needed:**
- Partner work
- Visual guides
- Shorter tasks

---

## 📚 MATERIALS NEEDED

### Week 1 - Mesopotamia:
- Clay/playdough
- Cardboard tubes
- Water & containers
- Story props
- Art supplies

### Week 2 - Egypt:
- Brown paper bags
- Paint & brushes
- Rope (12 feet)
- Salt & containers
- Masks materials

### Both Weeks:
- Chart paper
- Markers/crayons
- Rulers
- Journals
- Celebration supplies

---

## 🏠 FAMILY CONNECTIONS

### Weekly Home Extensions:

**Week 1 Ideas:**
- Share family stories
- Find patterns at home
- Count in different bases
- Water experiments

**Week 2 Ideas:**
- Create family symbols
- Measure rooms
- Preservation experiments
- Code making

### Communication:
- Daily photo updates
- Weekly newsletters
- Student showcase invites
- Take-home activities

---

## 🌟 SUCCESS CELEBRATIONS

### Student Achievements:
- Discovery badges
- Problem-solver awards
- Creativity certificates
- Teamwork recognition

### Class Milestones:
- Civilization museum
- Parent presentations
- Cross-grade sharing
- Digital portfolio

**Remember:** Every child is an explorer, creator, and problem-solver!

---

## 🎊 GRAND FINALE

### End of Month Celebration:
**Ancient Civilizations Festival**

Students will:
- Present their favorite discoveries
- Display their artifacts
- Perform myths
- Share their learning journey

Parents will:
- See the classroom museum
- Try hands-on activities
- Celebrate growth
- Plan next adventures

**The journey through time continues...**
Next Month: Greece & China await!
