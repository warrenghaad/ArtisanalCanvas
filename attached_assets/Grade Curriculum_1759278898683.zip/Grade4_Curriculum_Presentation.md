# GRADE 4: EXPANDING HORIZONS
## Advanced Ancient Civilizations | 2 Five-Day Cycles

---

## 🌍 WELCOME FOURTH GRADE EXPLORERS!
### Your Advanced Civilization Quest

**Your Mission:**
- 🏛️ Master mathematical thinking from ancient Greece
- 🎨 Discover harmony in Chinese innovations
- 🔬 Apply scientific methods to historical problems
- 🌟 Connect ancient wisdom to modern life

**Duration:** 20 Days (4 Weeks)
**Ages:** 9-10 years old
**Focus:** Critical thinking & connections

---

## 📅 WEEK 1: ANCIENT GREECE
### The Birth of Logic & Beauty

**🗺️ Location:** Mediterranean Peninsula
**📅 Time Period:** 800-146 BCE
**🏆 Major Achievements:**
- Democracy
- Mathematical proofs
- Olympic Games
- Philosophy & Theater

---

## MONDAY - MYTH DAY 📖
### The Odyssey: A Hero's Journey

**Epic Introduction (25 min):**
- Map Odysseus's 10-year journey
- Identify challenges and solutions

**Advanced Activities:**
- 🗺️ Create interactive journey maps
- 📊 Problem-solving flow charts
- 🎭 Character perspective journals
- 🎯 Design your hero's journey wheel

**SEL Focus:** Perseverance & Courage

---

## TUESDAY - ART DAY 🎨
### Greek Pottery & Geometric Design

**Art as Mathematics:**
- Discover symmetry in amphora designs
- Analyze geometric borders

**Create & Analyze:**
- Design narrative pottery
- Explore reflection symmetry
- Create rotation patterns
- Mathematical art critique

**Integration:** Measure angles in designs

---

## WEDNESDAY - MATH DAY 🔢
### Pythagorean Theorem Discovery

**The Big Proof:** a² + b² = c²

**Investigations:**
- Prove with paper squares
- Measure classroom diagonals
- Find right triangles everywhere
- Create proof artwork

**Applications:**
- Architecture
- Navigation
- Video game design
- Sports fields

---

## THURSDAY - PROBLEM DAY 🔧
### Amphitheater Acoustics

**Engineering Challenge:**
Design a theater where everyone can hear perfectly!

**Scientific Method:**
- Hypothesis about sound travel
- Test different shapes
- Measure sound levels
- Optimize design

**Presentation:** Perform in your amphitheater!

---

## FRIDAY - REVELATION DAY 💡
### Democracy is Born!

**Revolutionary Idea:**
- Experience Athenian voting
- Design fair voting systems
- Debate class issues
- Create democracy charter

**Modern Connection:** How do we vote today?

---

## 📅 WEEK 2: ANCIENT CHINA
### Harmony, Balance & Innovation

**🗺️ Location:** Yellow & Yangtze Rivers
**📅 Time Period:** 1046 BCE - 1644 CE
**🏆 Major Achievements:**
- Paper & printing
- Compass
- Gunpowder
- Great Wall

---

## MONDAY - MYTH DAY 📖
### Journey to the West

**The Monkey King's Adventure:**
- Character transformation arcs
- Moral dilemmas & solutions

**Deep Thinking Activities:**
- 📜 Create journey scrolls
- 🎭 Character evolution charts
- 💭 Wisdom collection books
- 🗺️ Transformation timelines

**SEL Focus:** Growth Mindset & Self-Management

---

## TUESDAY - ART DAY 🎨
### Chinese Calligraphy & Balance

**Art of the Brush:**
- Basic stroke mastery
- Character construction
- Balance in composition

**Cultural Creation:**
- Practice brush techniques
- Design name scrolls
- Create class poem
- Silk painting exploration

**Mathematics:** Symmetry in characters

---

## WEDNESDAY - MATH DAY 🔢
### Tangram Geometry Master

**Seven Pieces, Infinite Possibilities**

**Mathematical Investigations:**
- Prove all 13 convex shapes
- Calculate areas & perimeters
- Explore fractions
- Design challenge cards

**Spatial Reasoning:**
- 2D transformations
- Rotation & reflection
- Scale & proportion

---

## THURSDAY - PROBLEM DAY 🔧
### Great Wall Logistics

**Mega-Engineering Challenge:**
How do you build across 13,000 miles?

**Complex Problem Solving:**
- Calculate materials needed
- Design transport systems
- Test structural strength
- Cost-benefit analysis

**Math Modeling:** Scale, proportion, estimation

---

## FRIDAY - REVELATION DAY 💡
### Paper Changes Everything!

**Information Revolution:**
- Make recycled paper
- Create printing blocks
- Publish class newsletter
- Design information systems

**Future Thinking:** From paper to internet

---

## 📊 ADVANCED ASSESSMENT

### Performance Tasks:
**Daily:**
- Complex exit tickets
- Peer evaluations
- Process documentation
- Reflection depth

**Weekly:**
- Project presentations
- Mathematical proofs
- Research reports
- Leadership roles

---

## 🎯 DIFFERENTIATION STRATEGIES

### Challenge Levels:

**Level 1 - Foundation:**
- Guided practice
- Visual supports
- Partner work
- Modified goals

**Level 2 - Grade Level:**
- Standard challenges
- Independent work
- Full participation
- Expected outcomes

**Level 3 - Extension:**
- Additional constraints
- Research components
- Teaching others
- Creative innovations

---

## 🔬 INTEGRATED SKILLS

### Cross-Curricular Connections:

**Mathematics:**
- Geometry proofs
- Data analysis
- Pattern recognition
- Problem solving

**Science:**
- Scientific method
- Engineering design
- Hypothesis testing
- Data collection

**Language Arts:**
- Research skills
- Presentation speaking
- Technical writing
- Critical reading

**Social Studies:**
- Historical thinking
- Cultural appreciation
- Geographic understanding
- Civic engagement

---

## 📚 ADVANCED MATERIALS

### Week 1 - Greece:
- Compass & protractor
- Grid paper
- Sound meters (app)
- Voting materials
- Amphora templates

### Week 2 - China:
- Calligraphy brushes
- Ink & rice paper
- Tangram sets
- Building materials
- Paper-making kit

### Technology:
- Tablets for research
- Sound recording
- Digital portfolios
- Virtual field trips

---

## 🏠 FAMILY PARTNERSHIPS

### Advanced Home Extensions:

**Week 1 Projects:**
- Family democracy meetings
- Pythagorean theorem hunt
- Greek recipe cooking
- Theater performances

**Week 2 Projects:**
- Tangram challenges
- Calligraphy practice
- Paper making
- Family newsletter

### Parent Expertise:
- Guest speakers
- Skill sharing
- Cultural connections
- Career connections

---

## 💡 STUDENT LEADERSHIP

### Opportunities:

**Classroom Roles:**
- Research director
- Materials manager
- Tech coordinator
- Presentation coach

**Peer Teaching:**
- Skill workshops
- Problem helpers
- Discovery shares
- Celebration planning

**Documentation:**
- Class historian
- Photo journalist
- Portfolio curator
- Newsletter editor

---

## 🏆 ACHIEVEMENT SYSTEM

### Mastery Badges:

**Academic:**
- 🏛️ Greek Mathematician
- 🎨 Master Artist
- 🔬 Scientific Thinker
- 📚 Research Expert

**Character:**
- 💪 Perseverance Champion
- 🤝 Collaboration Star
- 💡 Innovation Leader
- 🌟 Growth Mindset Hero

**Special Recognition:**
- Problem Solver of the Week
- Creative Thinker Award
- Leadership Excellence
- Peer Support Medal

---

## 🌐 GLOBAL CONNECTIONS

### Real-World Applications:

**Modern Greece:**
- Video call with Greek school
- Olympics connection
- Architecture influence

**Modern China:**
- Partner classroom
- Cultural exchange
- Innovation examples

**Local Connections:**
- Museum field trips
- Expert visitors
- Community projects

---

## 🎊 CULMINATING CELEBRATION

### Ancient Wisdom Modern Application Fair

**Student Exhibitions:**
- Interactive demonstrations
- Mathematical proofs gallery
- Engineering solutions
- Cultural performances

**Family Participation:**
- Try activities
- Vote on projects
- Share expertise
- Celebrate growth

**Documentation:**
- Digital portfolios
- Video presentations
- Published newsletter
- Certificate ceremony

**Next Adventure Preview:**
Islamic Golden Age & Renaissance await!
