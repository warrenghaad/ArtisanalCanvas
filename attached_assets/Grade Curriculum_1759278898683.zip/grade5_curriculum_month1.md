# Grade 5 Pyramedic Curriculum - Month 1
## Two 5-Day Learning Cycles

### Overview
- **Schedule**: Tuesdays & Thursdays, 45-minute sessions
- **Cycles**: Islamic Golden Age (Week 1-2) and Renaissance Italy (Week 3-4)
- **Framework**: Myth → Art → Math → Problem → Solution
- **Grade 5 Focus**: Complex synthesis, historical connections, innovation principles

---

## CYCLE 1: ISLAMIC GOLDEN AGE (House of Wisdom Era)

### Day 1 (Tuesday, Week 1): MYTH - One Thousand and One Nights
**Learning Objectives:**
- Analyze frame narrative structure
- Explore knowledge preservation themes
- Develop metacognitive awareness

**Activities:**
- Scheherazade's strategy discussion
- Create nested story structures
- Examine how stories preserve wisdom
- Write mathematical riddles in story form

**Literary Analysis:**
- Frame narratives and embedded tales
- Stories as knowledge vessels
- Cultural transmission through narrative
- Mathematical puzzles in literature

**SEL Integration:**
- Strategic thinking
- Persistence through storytelling
- Cultural wisdom preservation
- Power of knowledge

### Day 2 (Tuesday, Week 1): ART - Geometric Tessellations
**Learning Objectives:**
- Create complex geometric patterns
- Understand infinite pattern principles
- Explore art without representation

**Activities:**
- Design Islamic star patterns
- Create tessellations using polygons
- Explore symmetry transformations
- Build 3D geometric models

**Mathematical Art Concepts:**
- Regular polygon tessellations
- Rotational symmetry
- Translations and reflections
- Infinite pattern generation
- Sacred geometry principles

### Day 3 (Tuesday, Week 1): MATH - Algebra's Beginning
**Learning Objectives:**
- Understand variables as unknowns
- Solve basic algebraic equations
- Connect algebra to real problems

**Activities:**
- Al-Khwarizmi's method exploration
- Balance scale equation solving
- Create "al-jabr" (restoration) problems
- Code breaking with algebra

**Advanced Mathematical Concepts:**
- Variable representation
- Equation balancing
- Word problem translation
- Algorithm development
- Mathematical notation evolution

### Day 4 (Thursday, Week 2): PROBLEM - Caravan Route Optimizer
**Learning Objectives:**
- Apply algebraic thinking to logistics
- Calculate with multiple variables
- Optimize resource distribution

**Complex Challenge:**
- Plan caravan route from Baghdad to Cordoba
- Calculate supplies needed (algebraic formulas)
- Factor in stops, seasons, and trade values
- Design profit maximization strategy

**Real-World Applications:**
- Supply chain mathematics
- Variable manipulation
- Profit/loss calculations
- Risk assessment
- Route optimization

### Day 5 (Thursday, Week 2): SOLUTION - Algorithm Invention
**Learning Objectives:**
- Understand algorithms as step-by-step solutions
- Create original algorithms
- Connect to modern computing

**Activities:**
- Present caravan solutions as algorithms
- Create algorithms for daily tasks
- Discuss how algorithms led to computers
- Celebrate becoming algorithm inventors

**Breakthrough Moment:**
Students realize they've created the precursors to computer programs through systematic problem-solving

---

## CYCLE 2: RENAISSANCE ITALY (Rebirth of Learning)

### Day 1 (Tuesday, Week 3): MYTH - Dante's Journey
**Learning Objectives:**
- Explore allegorical storytelling
- Understand knowledge synthesis
- Analyze mathematical structure in literature

**Activities:**
- Simplified Dante's Inferno exploration
- Map the nine circles mathematically
- Discuss allegory and symbolism
- Create personal learning journey maps

**Interdisciplinary Connections:**
- Literature and mathematics fusion
- Moral philosophy through structure
- Geographic and geometric thinking
- Knowledge as journey metaphor

### Day 2 (Tuesday, Week 3): ART - Linear Perspective
**Learning Objectives:**
- Master one-point perspective drawing
- Understand mathematical basis of realistic art
- Apply vanishing point principles

**Activities:**
- Brunelleschi's perspective experiment
- Draw classroom in perspective
- Create impossible perspectives (Escher-style)
- Analyze perspective in famous paintings

**Art-Math Integration:**
- Horizon lines and vanishing points
- Proportional relationships
- Mathematical rules in art
- 3D representation on 2D surface
- Golden ratio in composition

### Day 3 (Tuesday, Week 3): MATH - Fibonacci Sequence
**Learning Objectives:**
- Discover patterns in number sequences
- Find Fibonacci in nature
- Understand recursive relationships

**Activities:**
- Generate Fibonacci sequence
- Fibonacci spiral construction
- Nature scavenger hunt (petals, shells)
- Create Fibonacci art projects

**Advanced Pattern Recognition:**
- Recursive sequences
- Golden ratio connection
- Natural mathematics
- Pattern prediction
- Mathematical beauty

### Day 4 (Thursday, Week 4): PROBLEM - Dome Engineering Challenge
**Learning Objectives:**
- Apply geometric principles to engineering
- Solve structural challenges
- Integrate art, math, and science

**Engineering Challenge:**
- Design dome like Brunelleschi's
- Calculate material needs
- Consider weight distribution
- Build scale model with materials
- Present with mathematical justification

**STEAM Integration:**
- Structural engineering
- Geometric calculation
- Artistic design
- Material science
- Presentation skills

### Day 5 (Thursday, Week 4): SOLUTION - Renaissance Synthesis
**Learning Objectives:**
- Connect Islamic and Renaissance innovations
- Understand knowledge transmission
- Celebrate polymathic thinking

**Activities:**
- Present dome solutions
- Trace knowledge from Islamic world to Renaissance
- Create "genius gallery" of innovations
- Design personal "renaissance" learning plan

**Culminating Understanding:**
Innovation happens when different knowledge traditions merge and build upon each other

---

## Grade 5 Advanced Components

### Critical Thinking Skills:
- **Analysis**: Compare civilizations' approaches
- **Synthesis**: Merge different knowledge systems
- **Evaluation**: Judge effectiveness of solutions
- **Creation**: Design original algorithms and structures

### Mathematical Progressions:
- Pre-algebra concepts
- Complex pattern recognition
- Multi-step problem solving
- Mathematical proof introduction
- Real-world applications

### SEL Development:
- **Self-Awareness**: Recognizing learning styles
- **Self-Management**: Long-term project planning
- **Social Awareness**: Cultural contributions appreciation
- **Relationship Skills**: Complex collaboration
- **Responsible Decision-Making**: Ethical innovation

### Assessment Strategies:

**Formative Assessments:**
- Daily exit tickets with reflection
- Peer evaluation of projects
- Self-assessment rubrics
- Progress monitoring charts

**Summative Assessments:**
- Portfolio of both cycles' work
- Presentation of learning journey
- Cross-civilization comparison essay
- Mathematical problem creation

### Differentiation for Grade 5:

**Extension Opportunities:**
- Research original sources
- Create teaching materials for younger grades
- Develop online presentations
- Lead mathematical investigations

**Support Strategies:**
- Visual thinking maps
- Step-by-step guides
- Peer tutoring partnerships
- Modified complexity options

### Family & Community Connections:
- Family STEAM night presentations
- Community architecture walking tour
- Library research projects
- Museum mathematics workshops
- Cultural center visits

### Technology Integration:
- 3D modeling software for domes
- Pattern generation apps
- Virtual Islamic art museums
- Fibonacci in nature photography
- Algorithm coding introduction

### Standards Alignment:
- Common Core Math: 5.OA, 5.NBT, 5.NF, 5.G
- NGSS: 5-ETS1-1,2,3 (Engineering Design)
- NCSS: Science, Technology, and Society
- C3 Framework: Taking Informed Action

### Cross-Curricular Connections:
- **ELA**: Complex text analysis, narrative writing
- **Science**: Engineering design, natural patterns
- **Social Studies**: Cultural exchange, historical cause-effect
- **Art**: Mathematical art principles
- **Technology**: Algorithm development

### Next Month Preview:
Industrial Revolution (innovation acceleration) and Modern Digital Age (pattern recognition in data)