# Grade 4 Pyramedic Curriculum - Month 1
## Two 5-Day Learning Cycles

### Overview
- **Schedule**: Tuesdays & Thursdays, 45-minute sessions
- **Cycles**: Ancient Greece (Week 1-2) and Maya Civilization (Week 3-4)
- **Framework**: Myth → Art → Math → Problem → Solution
- **Grade 4 Focus**: Abstract thinking, cross-cultural connections, advanced problem-solving

---

## CYCLE 1: ANCIENT GREECE (Birthplace of Democracy)

### Day 1 (Tuesday, Week 1): MYTH - Perseus and Medusa
**Learning Objectives:**
- Analyze hero's journey structure
- Identify universal themes in mythology
- Develop moral reasoning skills (SEL)

**Activities:**
- Interactive retelling of Perseus myth
- Map hero's journey stages
- Debate: "Is it okay to use enemy's weapons against them?"
- Create modern hero's journey examples

**Higher-Order Thinking:**
- Compare to modern superhero stories
- Analyze character motivations
- Evaluate ethical dilemmas

### Day 2 (Tuesday, Week 1): ART - Greek Pottery & Patterns
**Learning Objectives:**
- Master geometric patterns in Greek art
- Understand visual storytelling techniques
- Create narrative art pieces

**Activities:**
- Study red and black figure pottery styles
- Design amphora with geometric borders
- Tell stories through sequential art
- Learn about golden ratio in design

**Artistic Elements:**
- Meander patterns
- Symmetry and balance
- Figure-ground relationships
- Narrative composition

### Day 3 (Tuesday, Week 1): MATH - Pythagorean Theorem Introduction
**Learning Objectives:**
- Explore right triangles and squares
- Understand proof through visual demonstration
- Apply theorem to real-world problems

**Activities:**
- Hands-on proof with square tiles
- Measure classroom diagonals
- Create "proof without words" posters
- Pythagorean triple treasure hunt

**Mathematical Concepts:**
- a² + b² = c²
- Visual proofs
- Practical applications
- Number patterns (3-4-5, 5-12-13)

### Day 4 (Thursday, Week 2): PROBLEM - Olympic Stadium Design
**Learning Objectives:**
- Apply geometric principles to design
- Calculate perimeters and areas
- Collaborate on complex projects

**Challenge:**
- Design an Olympic stadium using Greek mathematics
- Include running track (stadium length)
- Calculate seating using multiplication
- Present designs with mathematical justification

**21st Century Skills:**
- Architectural thinking
- Mathematical modeling
- Presentation skills
- Team collaboration

### Day 5 (Thursday, Week 2): SOLUTION - Democratic Decision
**Learning Objectives:**
- Synthesize week's learning
- Practice democratic voting
- Connect ancient innovations to modern life

**Activities:**
- Stadium design presentations
- Democratic vote on best design
- Discuss how Greek math influences modern architecture
- Celebration: Greek Olympics mini-games

**Breakthrough Understanding:**
Mathematical proof and democratic process both seek truth through systematic methods

---

## CYCLE 2: MAYA CIVILIZATION (Masters of Time)

### Day 1 (Tuesday, Week 3): MYTH - The Hero Twins
**Learning Objectives:**
- Explore duality in Maya mythology
- Understand cyclical time concepts
- Develop cultural appreciation

**Activities:**
- Popol Vuh Hero Twins adventure
- Create comic strips of the ball game
- Discuss cycles in nature and stories
- Compare to Greek hero myths

**Cultural Insights:**
- Ball game as cosmic battle
- Underworld journey symbolism
- Resurrection and renewal themes
- Sacred numbers and cycles

### Day 2 (Tuesday, Week 3): ART - Maya Glyphs and Codices
**Learning Objectives:**
- Create pictographic writing systems
- Design accordion-fold books
- Incorporate mathematical symbols in art

**Activities:**
- Learn 15 basic Maya glyphs
- Create personal name glyphs
- Make accordion codex books
- Combine art with calendar symbols

**Artistic Techniques:**
- Pictographic communication
- Symbolic representation
- Color symbolism (directions)
- Sacred geometry in design

### Day 3 (Tuesday, Week 3): MATH - Base-20 and Zero
**Learning Objectives:**
- Master place value in base-20
- Understand the concept of zero
- Compare number systems

**Activities:**
- Count using dots and bars
- Explore Maya number stacking
- Calculate dates in Long Count
- Create base-20 multiplication tables

**Advanced Concepts:**
- Positional notation
- Zero as placeholder and number
- Calendar mathematics
- Venus cycle calculations

### Day 4 (Thursday, Week 4): PROBLEM - Eclipse Predictor
**Learning Objectives:**
- Use patterns to predict astronomical events
- Apply cyclical thinking
- Create data visualizations

**Challenge:**
- Build a Maya-style eclipse predictor
- Use pattern data to find cycles
- Create visual calendar wheel
- Predict next eclipse using patterns

**Scientific Thinking:**
- Pattern recognition
- Cycle identification
- Data visualization
- Predictive modeling

### Day 5 (Thursday, Week 4): SOLUTION - Time Keepers' Wisdom
**Learning Objectives:**
- Compare Greek linear and Maya cyclical thinking
- Synthesize different mathematical systems
- Celebrate diverse problem-solving approaches

**Activities:**
- Present eclipse predictors
- Compare Greek geometry with Maya astronomy
- Create timeline showing both civilizations
- Design class "Museum of Mathematical Minds"

**Culminating Insight:**
Different civilizations developed unique but equally valid mathematical systems to understand the universe

---

## Assessment & Differentiation

### Grade 4 Specific Skills:
- **Mathematical**: Multi-step problems, visual proofs, base conversions
- **Artistic**: Complex patterns, symbolic systems, narrative art
- **SEL**: Ethical reasoning, cultural empathy, democratic participation
- **Critical Thinking**: Comparative analysis, system thinking, prediction

### Differentiation Strategies:

**For Advanced Learners:**
- Research additional myths from each culture
- Explore advanced geometric proofs
- Create bilingual glyph dictionaries
- Lead peer tutoring sessions

**For Struggling Learners:**
- Provide myth summaries with visuals
- Use manipulatives for all math concepts
- Offer artistic templates
- Partner with stronger students

**For ELL Students:**
- Visual vocabulary cards
- Hands-on activities emphasized
- Native language resources when available
- Peer translation support

### Family Extensions:
- Visit planetarium for Maya astronomy
- Explore Greek architecture in your city
- Create family democracy for decisions
- Calculate home dimensions using Pythagorean theorem

### Standards Alignment:
- Common Core Math: 4.OA, 4.NBT, 4.MD, 4.G
- NGSS: 4-ESS1-1 (Earth's Systems)
- NCSS: People, Places, Environment
- C3 Framework: Dimension 2 - History

### Technology Integration:
- Virtual museum tours (Greece and Maya sites)
- Geometric design software
- Calendar calculation apps
- Digital storytelling tools

### Next Month Preview:
Ancient Rome (engineering marvels) and Ancient China (inventions and discoveries)