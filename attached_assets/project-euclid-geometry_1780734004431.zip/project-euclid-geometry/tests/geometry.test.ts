import { composeGeometry } from '../src/geometry/compose';
import { exportGraph } from '../src/geometry/exportGraph';
import { isEquivalentGECD, mergeGECD } from '../src/geometry/gecdMerge';
import { ingestGeometryConcept } from '../src/geometry/ingest';
import { loadAllGeometryRegistries } from '../src/geometry/loadRegistry';
import { buildGeometryTimeline } from '../src/geometry/timeline';

function assert(condition: unknown, message: string): void {
  if (!condition) throw new Error(message);
}

function assertIncludes(values: string[], expected: string, message: string): void {
  assert(values.includes(expected), `${message}. Expected ${expected} in ${JSON.stringify(values)}`);
}

const registry = loadAllGeometryRegistries(process.cwd());
const allGeaIds = new Set([...registry.geaBasic, ...registry.geaPetzinger32].map((item) => item.id));
const gemIds = new Set(registry.gemPatterns.map((item) => item.id));
const geaGemIds = new Set([...allGeaIds, ...gemIds]);
const gekIds = new Set(registry.gekConcepts.map((item) => item.id));
const gephrIds = new Set(registry.gephrMeanings.map((item) => item.id));

assert(registry.geaBasic.length >= 37, 'GEA basic registry loads with expected count');
assert(registry.geaPetzinger32.length === 32, 'Petzinger registry loads exactly 32 signs');
assert(registry.gemPatterns.length >= 25, 'GEM pattern registry loads with expected count');
assert(registry.gekConcepts.length >= 31, 'GEK concept registry loads with expected count');
assert(registry.gephrMeanings.length >= 25, 'GEpHR meaning registry loads with expected count');
assert(registry.gecdSeedNodes.length === 12, 'Mesopotamia seed registry loads exactly 12 GECD nodes');

for (const gem of registry.gemPatterns) {
  for (const component of gem.components) {
    assert(geaGemIds.has(component), `GEM ${gem.id} component ${component} must reference valid GEA/GEM`);
  }
}

for (const rule of registry.nestingRules) {
  for (const input of rule.input) assert(geaGemIds.has(input), `Rule ${rule.id} input ${input} valid`);
  for (const output of rule.output_candidates) assert(geaGemIds.has(output), `Rule ${rule.id} output ${output} valid`);
  for (const gek of rule.adds_geks) assert(gekIds.has(gek), `Rule ${rule.id} GEK ${gek} valid`);
  for (const gephr of rule.possible_gephrs) assert(gephrIds.has(gephr), `Rule ${rule.id} GEpHR ${gephr} valid`);
}

const radial = composeGeometry(['gea.circle', 'gea.radial_line'], registry).map((item) => item.id);
assertIncludes(radial, 'gem.sun_disk', 'circle + radial_line composes sun disk');
assertIncludes(radial, 'gem.rosette', 'circle + radial_line composes rosette candidate');
assertIncludes(radial, 'gem.rayed_circle', 'circle + radial_line composes rayed circle');

const squareTriangle = composeGeometry(['gea.square', 'gea.triangle'], registry).map((item) => item.id);
assertIncludes(squareTriangle, 'gem.house_profile', 'square + triangle returns house profile candidate');
assertIncludes(squareTriangle, 'gem.ziggurat_profile', 'square + triangle returns ziggurat profile candidate');
assertIncludes(squareTriangle, 'gem.stepped_profile', 'square + triangle returns stepped profile candidate');

const original = registry.gecdSeedNodes.find((node) => node.id === 'gecd.mesopotamia.shamash_sun_disk');
assert(original, 'Shamash seed node exists');
const evidence = JSON.parse(JSON.stringify(original));
evidence.notes = 'Additional catalogue evidence placeholder.';
evidence.carrier.source_url = 'https://example.org/catalogue/shamash-sun-disk';
evidence.registers.function.gek_ids.push('gek.diameter');
assert(isEquivalentGECD(original!, evidence), 'Equivalent GECD records detected for merge');
const merged = mergeGECD(original!, evidence);
assert(merged.id === original!.id, 'Merged GECD preserves original id and does not duplicate');
assert(merged.registers.function.gek_ids.includes('gek.diameter'), 'Merged GECD preserves new evidence');
assert((merged.source_history || []).length === 1, 'Merged GECD keeps source history');

const timeline = buildGeometryTimeline(registry.gecdSeedNodes);
assert(timeline.groups.by_element['gea.circle'].length >= 3, 'Timeline groups nodes by element');
assert(timeline.groups.by_carrier_type['tablet'].includes('gecd.mesopotamia.nabu_clay_tablet_rectangle'), 'Timeline groups nodes by carrier type');
assert(timeline.groups.by_civilization['Mesopotamia'].length === 12, 'Timeline groups nodes by civilization');

const graph = exportGraph(registry.gecdSeedNodes, registry);
assert(graph.nodes.some((node) => node.id === 'gecd.mesopotamia.shamash_sun_disk'), 'Graph includes GECD nodes');
assert(graph.edges.some((edge) => edge.type === 'appears_on'), 'Graph includes appears_on edges');
assert(graph.edges.some((edge) => edge.type === 'symbolizes'), 'Graph includes symbolizes edges');
assert(graph.edges.some((edge) => edge.type === 'formalizes_as'), 'Graph includes formalizes_as edges');
assert(graph.edges.some((edge) => edge.type === 'mechanizes_into'), 'Graph includes mechanizes_into edges');

const ingest = ingestGeometryConcept('circle', { civilization: 'Mesopotamia' }, registry);
assert(ingest.matched_ids.includes('gea.circle'), 'Ingest finds circle GEA');
assert(ingest.research_queries.length >= 3, 'Ingest produces research queries');
assert(ingest.design_brief.prompt.includes('Day A') && ingest.design_brief.prompt.includes('Day B'), 'Ingest design prompt preserves register split');

console.log('All geometry ontology tests passed.');

