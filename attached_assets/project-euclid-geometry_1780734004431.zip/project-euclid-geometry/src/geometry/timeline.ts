import type { GECDNode, GeometryTimeline } from './types';

function add(group: Record<string, string[]>, key: string, id: string): void {
  if (!group[key]) group[key] = [];
  if (!group[key].includes(id)) group[key].push(id);
}

function timeKey(node: GECDNode): string {
  const start = node.date_range.start_bce;
  const end = node.date_range.end_bce;
  if (start === null && end === null) return 'undated';
  if (start !== null && end !== null) return `${start}-${end} BCE`;
  if (start !== null) return `from ${start} BCE`;
  return `until ${end} BCE`;
}

function sortedNodes(nodes: GECDNode[]): GECDNode[] {
  return [...nodes].sort((a, b) => {
    const ay = a.date_range.start_bce ?? -Infinity;
    const by = b.date_range.start_bce ?? -Infinity;
    return by - ay;
  });
}

export function buildGeometryTimeline(nodes: GECDNode[]): GeometryTimeline {
  const timeline: GeometryTimeline = {
    generated_at: new Date().toISOString(),
    groups: {
      by_time: {},
      by_civilization: {},
      by_element: {},
      by_molecule: {},
      by_carrier_type: {},
      by_dimension_shift: {},
      by_gek: {},
      by_gephr: {},
    },
    nodes: sortedNodes(nodes),
  };

  for (const node of timeline.nodes) {
    add(timeline.groups.by_time, timeKey(node), node.id);
    add(timeline.groups.by_civilization, node.civilization, node.id);
    add(timeline.groups.by_carrier_type, node.carrier.type, node.id);
    add(timeline.groups.by_dimension_shift, `${node.dimension.from_dimension}->${node.dimension.to_dimension}:${node.dimension.spatial_mode}`, node.id);
    for (const element of node.elements) add(timeline.groups.by_element, element, node.id);
    for (const molecule of node.molecules) add(timeline.groups.by_molecule, molecule, node.id);
    for (const gek of node.registers.function.gek_ids) add(timeline.groups.by_gek, gek, node.id);
    for (const gephr of node.registers.metaphor.gephr_ids) add(timeline.groups.by_gephr, gephr, node.id);
  }

  return timeline;
}

