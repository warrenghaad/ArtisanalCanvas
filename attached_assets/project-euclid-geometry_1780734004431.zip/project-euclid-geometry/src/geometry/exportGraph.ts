import type { GECDNode, GeometryGraph, GeometryRegistries, GraphEdge, GraphNode } from './types';
import { loadAllGeometryRegistries } from './loadRegistry';

function addNode(nodes: Map<string, GraphNode>, node: GraphNode): void {
  if (!nodes.has(node.id)) nodes.set(node.id, node);
}

function edgeKey(edge: GraphEdge): string {
  return `${edge.source}|${edge.type}|${edge.target}`;
}

function addEdge(edges: Map<string, GraphEdge>, edge: GraphEdge): void {
  edges.set(edgeKey(edge), edge);
}

function carrierId(node: GECDNode): string {
  return `carrier.${node.civilization.toLowerCase().replace(/[^a-z0-9]+/g, '_')}.${node.carrier.type}.${node.carrier.label.toLowerCase().replace(/[^a-z0-9]+/g, '_')}`;
}

export function exportGraph(nodes: GECDNode[], registry: GeometryRegistries = loadAllGeometryRegistries()): GeometryGraph {
  const graphNodes = new Map<string, GraphNode>();
  const graphEdges = new Map<string, GraphEdge>();

  for (const gea of [...registry.geaBasic, ...registry.geaPetzinger32]) addNode(graphNodes, { id: gea.id, label: gea.label, kind: 'GEA', metadata: { category: gea.category } });
  for (const gem of registry.gemPatterns) {
    addNode(graphNodes, { id: gem.id, label: gem.label, kind: 'GEM', metadata: { composition_type: gem.composition_type } });
    for (const component of gem.components) addEdge(graphEdges, { source: component, target: gem.id, type: 'combines_into', label: 'component' });
  }
  for (const gek of registry.gekConcepts) addNode(graphNodes, { id: gek.id, label: gek.label, kind: 'GEK' });
  for (const gephr of registry.gephrMeanings) addNode(graphNodes, { id: gephr.id, label: gephr.label, kind: 'GEpHR' });

  for (const node of nodes) {
    addNode(graphNodes, { id: node.id, label: node.label, kind: 'GECD', metadata: { civilization: node.civilization, period: node.period, role: node.historical_role } });
    const cId = carrierId(node);
    addNode(graphNodes, { id: cId, label: node.carrier.label, kind: 'carrier', metadata: node.carrier as unknown as Record<string, unknown> });

    for (const element of node.elements) addEdge(graphEdges, { source: element, target: node.id, type: 'appears_on', label: node.carrier.type });
    for (const molecule of node.molecules) addEdge(graphEdges, { source: molecule, target: node.id, type: 'appears_on', label: node.carrier.type });
    addEdge(graphEdges, { source: node.id, target: cId, type: 'appears_on', label: 'carrier anchor' });

    for (const gephr of node.registers.metaphor.gephr_ids) addEdge(graphEdges, { source: node.id, target: gephr, type: 'symbolizes', label: 'Day A metaphor register' });
    for (const gek of node.registers.function.gek_ids) addEdge(graphEdges, { source: node.id, target: gek, type: 'formalizes_as', label: 'Day B function register' });

    for (const target of node.nesting.contains) addEdge(graphEdges, { source: node.id, target, type: 'contains' });
    for (const target of node.nesting.contained_by) addEdge(graphEdges, { source: target, target: node.id, type: 'contains' });
    for (const target of node.nesting.precedes) addEdge(graphEdges, { source: node.id, target, type: 'precedes' });
    for (const target of node.nesting.enables) addEdge(graphEdges, { source: node.id, target, type: 'enables' });
    for (const target of node.nesting.derived_from) addEdge(graphEdges, { source: target, target: node.id, type: 'precedes', label: 'derived_from' });

    if (node.dimension.to_dimension === '3D') addEdge(graphEdges, { source: node.id, target: cId, type: 'extrudes_into', label: `${node.dimension.from_dimension}->3D` });
    if (node.dimension.to_dimension === '4D_temporal_motion' || node.dimension.spatial_mode === 'mechanism' || node.dimension.spatial_mode === 'rotation') {
      addEdge(graphEdges, { source: node.id, target: cId, type: 'mechanizes_into', label: `${node.dimension.from_dimension}->${node.dimension.to_dimension}` });
    }
    if (node.historical_role === 'institutionalized_pattern' || node.carrier.type === 'tablet' || node.carrier.type === 'seal') {
      addEdge(graphEdges, { source: node.id, target: cId, type: 'institutionalizes_as', label: node.historical_role });
    }
    if (node.molecules.some((id) => /border|tessellation|grid|register/.test(id))) {
      addEdge(graphEdges, { source: node.id, target: cId, type: 'repeats_as', label: 'repetition/register system' });
    }
  }

  return { nodes: Array.from(graphNodes.values()), edges: Array.from(graphEdges.values()) };
}

