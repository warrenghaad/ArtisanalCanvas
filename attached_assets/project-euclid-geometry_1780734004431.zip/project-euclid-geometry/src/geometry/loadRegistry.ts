import { readFileSync } from 'fs';
import { resolve } from 'path';
import type { GEA, GECDNode, GEK, GEM, GEpHR, GeometryRegistries, NestingRule } from './types';

interface ValidationContext {
  errors: string[];
}

function loadJson<T>(path: string): T {
  const raw = readFileSync(path, 'utf8');
  return JSON.parse(raw) as T;
}

function requireArray(value: unknown, file: string, ctx: ValidationContext): void {
  if (!Array.isArray(value)) ctx.errors.push(`${file} must contain a JSON array.`);
}

function requireFields(item: Record<string, unknown>, fields: string[], label: string, ctx: ValidationContext): void {
  for (const field of fields) {
    if (!(field in item)) ctx.errors.push(`${label} missing required field: ${field}`);
  }
}

function uniqueIds(items: Array<{ id: string }>, label: string, ctx: ValidationContext): void {
  const seen = new Set<string>();
  for (const item of items) {
    if (!item.id) ctx.errors.push(`${label} item missing id.`);
    if (seen.has(item.id)) ctx.errors.push(`Duplicate ${label} id: ${item.id}`);
    seen.add(item.id);
  }
}

function validateRefs(refs: string[], validIds: Set<string>, label: string, ctx: ValidationContext): void {
  for (const ref of refs || []) {
    if (!validIds.has(ref)) ctx.errors.push(`${label} references missing id: ${ref}`);
  }
}

function validateGeas(items: GEA[], label: string, ctx: ValidationContext): void {
  uniqueIds(items, label, ctx);
  for (const item of items) {
    requireFields(item as unknown as Record<string, unknown>, ['id','label','category','dimensional_seed','formal_properties','visual_features','recognition_keywords','aliases','possible_geks','possible_gephrs','svg_hint','notes'], `${label}:${item.id}`, ctx);
    if (!item.id.startsWith('gea.')) ctx.errors.push(`${label}:${item.id} must start with gea.`);
  }
}

function validateGems(items: GEM[], validIds: Set<string>, ctx: ValidationContext): void {
  uniqueIds(items, 'GEM', ctx);
  for (const item of items) {
    requireFields(item as unknown as Record<string, unknown>, ['id','label','composition_type','components','composition_rule','formal_properties','visual_features','possible_carriers','possible_geks','possible_gephrs','historical_examples','notes'], `GEM:${item.id}`, ctx);
    if (!item.id.startsWith('gem.')) ctx.errors.push(`GEM:${item.id} must start with gem.`);
    validateRefs(item.components, validIds, `GEM:${item.id}.components`, ctx);
  }
}

function validateConcepts(items: GEK[], validGeasGems: Set<string>, ctx: ValidationContext): void {
  uniqueIds(items, 'GEK', ctx);
  for (const item of items) {
    if (!item.id.startsWith('gek.')) ctx.errors.push(`GEK:${item.id} must start with gek.`);
    validateRefs([...(item.associated_geas || []), ...(item.associated_gems || [])], validGeasGems, `GEK:${item.id}.associations`, ctx);
  }
}

function validateMeanings(items: GEpHR[], validGeasGems: Set<string>, ctx: ValidationContext): void {
  uniqueIds(items, 'GEpHR', ctx);
  for (const item of items) {
    if (!item.id.startsWith('gephr.')) ctx.errors.push(`GEpHR:${item.id} must start with gephr.`);
    validateRefs([...(item.associated_geas || []), ...(item.associated_gems || [])], validGeasGems, `GEpHR:${item.id}.associations`, ctx);
    if (item.caution !== 'Do not claim universality without source evidence.') {
      ctx.errors.push(`GEpHR:${item.id} must preserve caution field exactly.`);
    }
  }
}

function validateRules(rules: NestingRule[], validInputs: Set<string>, validOutputs: Set<string>, validGeks: Set<string>, validGephrs: Set<string>, ctx: ValidationContext): void {
  uniqueIds(rules, 'NestingRule', ctx);
  for (const rule of rules) {
    validateRefs(rule.input, validInputs, `Rule:${rule.id}.input`, ctx);
    validateRefs(rule.output_candidates, validOutputs, `Rule:${rule.id}.output_candidates`, ctx);
    validateRefs(rule.adds_geks, validGeks, `Rule:${rule.id}.adds_geks`, ctx);
    validateRefs(rule.possible_gephrs, validGephrs, `Rule:${rule.id}.possible_gephrs`, ctx);
  }
}

function validateSeeds(nodes: GECDNode[], validGeas: Set<string>, validGems: Set<string>, validGeks: Set<string>, validGephrs: Set<string>, ctx: ValidationContext): void {
  uniqueIds(nodes, 'GECD seed', ctx);
  for (const node of nodes) {
    requireFields(node as unknown as Record<string, unknown>, ['id','label','civilization','period','date_range','elements','molecules','carrier','dimension','registers','magic_signature','nesting','historical_role','notes'], `GECD:${node.id}`, ctx);
    if (!node.id.startsWith('gecd.')) ctx.errors.push(`GECD:${node.id} must start with gecd.`);
    validateRefs(node.elements, validGeas, `GECD:${node.id}.elements`, ctx);
    validateRefs(node.molecules, validGems, `GECD:${node.id}.molecules`, ctx);
    validateRefs(node.registers?.function?.gek_ids || [], validGeks, `GECD:${node.id}.registers.function`, ctx);
    validateRefs(node.registers?.metaphor?.gephr_ids || [], validGephrs, `GECD:${node.id}.registers.metaphor`, ctx);
  }
}

function validateGeaPossibilities(geas: GEA[], validGeks: Set<string>, validGephrs: Set<string>, ctx: ValidationContext): void {
  for (const item of geas) {
    validateRefs(item.possible_geks, validGeks, `${item.id}.possible_geks`, ctx);
    validateRefs(item.possible_gephrs, validGephrs, `${item.id}.possible_gephrs`, ctx);
    if (item.closest_basic_gea) {
      // Petzinger entries may map to basic GEAs. This is a reference check, not a semantic identity claim.
      // The full valid set includes the entry itself, so only prefix check here; global ref check happens below.
      if (!item.closest_basic_gea.startsWith('gea.')) ctx.errors.push(`${item.id}.closest_basic_gea must be a GEA id.`);
    }
  }
}

function buildIndex(registryParts: Array<Array<{ id: string }>>): Map<string, any> {
  const index = new Map<string, any>();
  for (const part of registryParts) {
    for (const item of part) index.set(item.id, item);
  }
  return index;
}

export function loadAllGeometryRegistries(rootDir = process.cwd()): GeometryRegistries {
  const registryDir = resolve(rootDir, 'src/geometry/registry');
  const seedDir = resolve(rootDir, 'src/geometry/seeds');

  const geaBasic = loadJson<GEA[]>(resolve(registryDir, 'gea.basic.json'));
  const geaPetzinger32 = loadJson<GEA[]>(resolve(registryDir, 'gea.petzinger32.json'));
  const gemPatterns = loadJson<GEM[]>(resolve(registryDir, 'gem.patterns.json'));
  const gekConcepts = loadJson<GEK[]>(resolve(registryDir, 'gek.concepts.json'));
  const gephrMeanings = loadJson<GEpHR[]>(resolve(registryDir, 'gephr.meanings.json'));
  const nestingRules = loadJson<NestingRule[]>(resolve(registryDir, 'nesting.rules.json'));
  const gecdSeedNodes = loadJson<GECDNode[]>(resolve(seedDir, 'mesopotamia.seed.json'));
  const gecdNode = loadJson<Record<string, unknown>>(resolve(registryDir, 'gecd.nodes.schema.json'));
  const historyTimeline = loadJson<Record<string, unknown>>(resolve(registryDir, 'history.timeline.schema.json'));

  const ctx: ValidationContext = { errors: [] };
  requireArray(geaBasic, 'gea.basic.json', ctx);
  requireArray(geaPetzinger32, 'gea.petzinger32.json', ctx);
  requireArray(gemPatterns, 'gem.patterns.json', ctx);
  requireArray(gekConcepts, 'gek.concepts.json', ctx);
  requireArray(gephrMeanings, 'gephr.meanings.json', ctx);
  requireArray(nestingRules, 'nesting.rules.json', ctx);
  requireArray(gecdSeedNodes, 'mesopotamia.seed.json', ctx);

  validateGeas(geaBasic, 'GEA basic', ctx);
  validateGeas(geaPetzinger32, 'GEA Petzinger32', ctx);

  const allGeas = [...geaBasic, ...geaPetzinger32];
  const geaIds = new Set(allGeas.map((item) => item.id));
  const gemIdsAfterLoad = new Set(gemPatterns.map((item) => item.id));
  const geaGemIds = new Set([...geaIds, ...gemIdsAfterLoad]);
  const gekIds = new Set(gekConcepts.map((item) => item.id));
  const gephrIds = new Set(gephrMeanings.map((item) => item.id));

  validateGems(gemPatterns, geaGemIds, ctx);
  validateConcepts(gekConcepts, geaGemIds, ctx);
  validateMeanings(gephrMeanings, geaGemIds, ctx);
  validateGeaPossibilities(allGeas, gekIds, gephrIds, ctx);
  validateRules(nestingRules, geaGemIds, geaGemIds, gekIds, gephrIds, ctx);
  validateSeeds(gecdSeedNodes, geaIds, gemIdsAfterLoad, gekIds, gephrIds, ctx);

  for (const petz of geaPetzinger32) {
    if (petz.closest_basic_gea && !geaIds.has(petz.closest_basic_gea)) {
      ctx.errors.push(`${petz.id}.closest_basic_gea references missing id: ${petz.closest_basic_gea}`);
    }
    if (petz.source_family !== 'petzinger_universal_signs') {
      ctx.errors.push(`${petz.id}.source_family must be petzinger_universal_signs`);
    }
  }

  if (gecdNode.type !== 'object') ctx.errors.push('gecd.nodes.schema.json must be an object schema.');
  if (historyTimeline.type !== 'object') ctx.errors.push('history.timeline.schema.json must be an object schema.');

  if (ctx.errors.length) {
    throw new Error(`Geometry registry validation failed:\n${ctx.errors.map((error) => `- ${error}`).join('\n')}`);
  }

  const idIndex = buildIndex([allGeas, gemPatterns, gekConcepts, gephrMeanings, nestingRules, gecdSeedNodes]);

  return {
    geaBasic,
    geaPetzinger32,
    gemPatterns,
    gekConcepts,
    gephrMeanings,
    nestingRules,
    gecdSeedNodes,
    schemas: { gecdNode, historyTimeline },
    idIndex,
  };
}

