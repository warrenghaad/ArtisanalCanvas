import type { GECDNode } from './types';

function normalize(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
}

function unique(values: string[]): string[] {
  return Array.from(new Set(values.filter(Boolean)));
}

function mergeStringArrays(a: string[] = [], b: string[] = []): string[] {
  return unique([...a, ...b]);
}

function centerYear(node: GECDNode): number | null {
  const start = node.date_range.start_bce;
  const end = node.date_range.end_bce;
  if (start === null && end === null) return null;
  if (start === null) return end;
  if (end === null) return start;
  return (start + end) / 2;
}

function approximateDateMatch(a: GECDNode, b: GECDNode, toleranceYears = 250): boolean {
  const ca = centerYear(a);
  const cb = centerYear(b);
  if (ca === null || cb === null) return true;
  return Math.abs(ca - cb) <= toleranceYears;
}

function overlapScore(a: string[], b: string[]): number {
  if (!a.length && !b.length) return 1;
  const setA = new Set(a);
  const both = b.filter((value) => setA.has(value)).length;
  return both / Math.max(a.length, b.length, 1);
}

export function isEquivalentGECD(existingNode: GECDNode, newEvidence: GECDNode): boolean {
  const sameCivilization = normalize(existingNode.civilization) === normalize(newEvidence.civilization);
  const sameCarrierType = existingNode.carrier.type === newEvidence.carrier.type;
  const carrierLabelMatch = normalize(existingNode.carrier.label) === normalize(newEvidence.carrier.label);
  const elementMatch = overlapScore(existingNode.elements, newEvidence.elements) >= 0.5;
  const moleculeMatch = overlapScore(existingNode.molecules, newEvidence.molecules) >= 0.5 || (!existingNode.molecules.length && !newEvidence.molecules.length);
  return sameCivilization && sameCarrierType && carrierLabelMatch && elementMatch && moleculeMatch && approximateDateMatch(existingNode, newEvidence);
}

function mostConfident(a: GECDNode['date_range']['confidence'], b: GECDNode['date_range']['confidence']): GECDNode['date_range']['confidence'] {
  const rank = { low: 1, medium: 2, high: 3 } as const;
  return rank[b] > rank[a] ? b : a;
}

function mergeDateRange(a: GECDNode['date_range'], b: GECDNode['date_range']): GECDNode['date_range'] {
  const starts = [a.start_bce, b.start_bce].filter((value): value is number => value !== null);
  const ends = [a.end_bce, b.end_bce].filter((value): value is number => value !== null);
  return {
    start_bce: starts.length ? Math.max(...starts) : null,
    end_bce: ends.length ? Math.min(...ends) : null,
    confidence: mostConfident(a.confidence, b.confidence),
  };
}

function mergeClaim(a: string, b: string): string {
  if (!b || a.includes(b)) return a;
  if (!a) return b;
  return `${a}\nMerged evidence: ${b}`;
}

export function mergeGECD(existingNode: GECDNode, newEvidence: GECDNode): GECDNode {
  if (!isEquivalentGECD(existingNode, newEvidence)) {
    throw new Error(`Cannot merge non-equivalent GECD nodes: ${existingNode.id} vs ${newEvidence.id}`);
  }

  const merged: GECDNode = JSON.parse(JSON.stringify(existingNode)) as GECDNode;
  merged.label = existingNode.label || newEvidence.label;
  merged.period = mergeClaim(existingNode.period, newEvidence.period);
  merged.date_range = mergeDateRange(existingNode.date_range, newEvidence.date_range);
  merged.elements = mergeStringArrays(existingNode.elements, newEvidence.elements);
  merged.molecules = mergeStringArrays(existingNode.molecules, newEvidence.molecules);
  merged.carrier = {
    ...existingNode.carrier,
    material: mergeClaim(existingNode.carrier.material, newEvidence.carrier.material),
    location: mergeClaim(existingNode.carrier.location, newEvidence.carrier.location),
    source_url: existingNode.carrier.source_url || newEvidence.carrier.source_url,
    source_citation: existingNode.carrier.source_citation || newEvidence.carrier.source_citation,
  };
  merged.registers = {
    metaphor: {
      gephr_ids: mergeStringArrays(existingNode.registers.metaphor.gephr_ids, newEvidence.registers.metaphor.gephr_ids),
      claim: mergeClaim(existingNode.registers.metaphor.claim, newEvidence.registers.metaphor.claim),
      confidence: mostConfident(existingNode.registers.metaphor.confidence, newEvidence.registers.metaphor.confidence),
    },
    function: {
      gek_ids: mergeStringArrays(existingNode.registers.function.gek_ids, newEvidence.registers.function.gek_ids),
      claim: mergeClaim(existingNode.registers.function.claim, newEvidence.registers.function.claim),
      confidence: mostConfident(existingNode.registers.function.confidence, newEvidence.registers.function.confidence),
    },
  };
  merged.nesting = {
    contains: mergeStringArrays(existingNode.nesting.contains, newEvidence.nesting.contains),
    contained_by: mergeStringArrays(existingNode.nesting.contained_by, newEvidence.nesting.contained_by),
    precedes: mergeStringArrays(existingNode.nesting.precedes, newEvidence.nesting.precedes),
    enables: mergeStringArrays(existingNode.nesting.enables, newEvidence.nesting.enables),
    derived_from: mergeStringArrays(existingNode.nesting.derived_from, newEvidence.nesting.derived_from),
  };
  merged.notes = mergeClaim(existingNode.notes, newEvidence.notes);
  merged.source_history = [
    ...(existingNode.source_history || []),
    {
      source_url: newEvidence.carrier.source_url,
      source_citation: newEvidence.carrier.source_citation,
      merged_at: new Date().toISOString(),
      evidence_note: newEvidence.notes,
    },
  ];
  merged.evidence_history = [...(existingNode.evidence_history || []), newEvidence];
  return merged;
}

