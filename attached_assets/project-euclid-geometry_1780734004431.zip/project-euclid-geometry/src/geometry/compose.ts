import { loadAllGeometryRegistries } from './loadRegistry';
import type { ComposeResult, GeometryRegistries } from './types';

function unique(values: string[]): string[] {
  return Array.from(new Set(values));
}

function hasAll(inputSet: Set<string>, required: string[]): boolean {
  return required.every((id) => inputSet.has(id));
}

function candidateToResult(id: string, registry: GeometryRegistries, source: ComposeResult['source'], rule_id?: string, condition?: string, added_geks: string[] = [], possible_gephrs: string[] = []): ComposeResult | null {
  const item = registry.idIndex.get(id) as any;
  if (!item || !('components' in item)) return null;
  return {
    id: item.id,
    label: item.label,
    source,
    rule_id,
    condition,
    added_geks: unique([...(item.possible_geks || []), ...added_geks]),
    possible_gephrs: unique([...(item.possible_gephrs || []), ...possible_gephrs]),
    components: item.components || [],
  };
}

export function composeGeometry(inputs: string[], registry = loadAllGeometryRegistries()): ComposeResult[] {
  const normalizedInputs = unique(inputs.map((value) => value.trim()).filter(Boolean));
  const inputSet = new Set(normalizedInputs);
  const byId = new Map<string, ComposeResult>();

  for (const rule of registry.nestingRules) {
    if (!hasAll(inputSet, rule.input)) continue;
    for (const candidate of rule.output_candidates) {
      const result = candidateToResult(candidate, registry, 'rule', rule.id, rule.condition, rule.adds_geks, rule.possible_gephrs);
      if (result) byId.set(result.id, result);
    }
  }

  for (const gem of registry.gemPatterns) {
    if (gem.components.length > 0 && hasAll(inputSet, gem.components)) {
      const result = candidateToResult(gem.id, registry, 'component_subset');
      if (result && !byId.has(result.id)) byId.set(result.id, result);
    }
  }

  return Array.from(byId.values()).sort((a, b) => a.id.localeCompare(b.id));
}

