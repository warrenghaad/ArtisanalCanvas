declare module 'fs' {
  export function readFileSync(path: string, encoding: BufferEncoding | string): string;
  export function writeFileSync(path: string, data: string, encoding?: BufferEncoding | string): void;
  export function existsSync(path: string): boolean;
  export function mkdirSync(path: string, options?: { recursive?: boolean }): string | undefined;
}

declare module 'path' {
  export function resolve(...paths: string[]): string;
  export function dirname(path: string): string;
  export function join(...paths: string[]): string;
}

declare type BufferEncoding = 'utf8' | 'utf-8' | string;
declare const process: {
  argv: string[];
  cwd(): string;
  exit(code?: number): never;
  exitCode?: number;
};
declare const require: any;
declare const module: any;

