export type DimensionSeed = '0D' | '1D' | '2D' | '3D';
export type DimensionTo = DimensionSeed | '4D_temporal_motion';

export type GEACategory =
  | 'basic_shape'
  | 'petzinger_sign'
  | 'mark'
  | 'line_family'
  | 'curve_family'
  | 'polygon'
  | 'volumetric_seed';

export interface GEA {
  id: string;
  label: string;
  category: GEACategory;
  dimensional_seed: DimensionSeed;
  formal_properties: string[];
  visual_features: string[];
  recognition_keywords: string[];
  aliases: string[];
  possible_geks: string[];
  possible_gephrs: string[];
  svg_hint: string;
  notes: string;
  closest_basic_gea?: string;
  source_family?: string;
  certainty_note?: string;
}

export type GEMCompositionType = 'GEA+GEA' | 'GEA+GEM' | 'GEM+GEM';

export interface GEM {
  id: string;
  label: string;
  composition_type: GEMCompositionType;
  components: string[];
  composition_rule: string;
  formal_properties: string[];
  visual_features: string[];
  possible_carriers: string[];
  possible_geks: string[];
  possible_gephrs: string[];
  historical_examples: string[];
  notes: string;
}

export interface GEK {
  id: string;
  label: string;
  register: 'function';
  definition: string;
  associated_geas: string[];
  associated_gems: string[];
  recognition_keywords: string[];
  day_b_relevance: string;
  notes: string;
}

export interface GEpHR {
  id: string;
  label: string;
  register: 'metaphor';
  summary: string;
  associated_geas: string[];
  associated_gems: string[];
  likely_civilizations: string[];
  day_a_relevance: string;
  visual_affordance_explanation: string;
  caution: string;
}

export type CarrierType =
  | 'artifact'
  | 'architecture'
  | 'inscription'
  | 'tool'
  | 'ritual_object'
  | 'image'
  | 'invention'
  | 'urban_plan'
  | 'textile'
  | 'seal'
  | 'tablet'
  | 'vessel';

export interface GECDCarrier {
  type: CarrierType;
  label: string;
  material: string;
  location: string;
  source_url: string;
  source_citation: string;
}

export interface GECDDateRange {
  start_bce: number | null;
  end_bce: number | null;
  confidence: 'low' | 'medium' | 'high';
}

export interface GECDDimension {
  spatial_mode:
    | 'mark'
    | 'surface'
    | 'relief'
    | 'volume'
    | 'rotation'
    | 'projection'
    | 'modular_system'
    | 'mechanism'
    | 'architectural_space';
  from_dimension: DimensionSeed;
  to_dimension: DimensionTo;
}

export interface GECDRegisterClaim {
  gephr_ids?: string[];
  gek_ids?: string[];
  claim: string;
  confidence: 'low' | 'medium' | 'high';
}

export interface GECDRegisters {
  metaphor: Required<Pick<GECDRegisterClaim, 'claim' | 'confidence'>> & { gephr_ids: string[] };
  function: Required<Pick<GECDRegisterClaim, 'claim' | 'confidence'>> & { gek_ids: string[] };
}

export interface MagicSignature {
  M: number | null;
  A: number | null;
  G: number | null;
  I: number | null;
  C: number | null;
  evidence_basis: string;
}

export interface GECDNesting {
  contains: string[];
  contained_by: string[];
  precedes: string[];
  enables: string[];
  derived_from: string[];
}

export type HistoricalRole =
  | 'early_mark'
  | 'symbolic_artifact'
  | 'technical_artifact'
  | 'invention'
  | 'architectural_system'
  | 'institutionalized_pattern'
  | 'mathematical_formalization';

export interface GECDNode {
  id: string;
  label: string;
  civilization: string;
  period: string;
  date_range: GECDDateRange;
  elements: string[];
  molecules: string[];
  carrier: GECDCarrier;
  dimension: GECDDimension;
  registers: GECDRegisters;
  magic_signature: MagicSignature;
  nesting: GECDNesting;
  historical_role: HistoricalRole;
  notes: string;
  source_history?: Array<{
    source_url: string;
    source_citation: string;
    merged_at: string;
    evidence_note?: string;
  }>;
  evidence_history?: Array<Partial<GECDNode>>;
}

export interface NestingRule {
  id: string;
  input: string[];
  output_candidates: string[];
  condition: string;
  adds_geks: string[];
  possible_gephrs: string[];
  edge_type?: GraphEdgeType;
}

export interface GeometryRegistries {
  geaBasic: GEA[];
  geaPetzinger32: GEA[];
  gemPatterns: GEM[];
  gekConcepts: GEK[];
  gephrMeanings: GEpHR[];
  nestingRules: NestingRule[];
  gecdSeedNodes: GECDNode[];
  schemas: {
    gecdNode: Record<string, unknown>;
    historyTimeline: Record<string, unknown>;
  };
  idIndex: Map<string, GEA | GEM | GEK | GEpHR | NestingRule | GECDNode>;
}

export interface ComposeResult {
  id: string;
  label: string;
  source: 'rule' | 'component_subset';
  rule_id?: string;
  condition?: string;
  added_geks: string[];
  possible_gephrs: string[];
  components: string[];
}

export type GraphEdgeType =
  | 'contains'
  | 'combines_into'
  | 'appears_on'
  | 'extrudes_into'
  | 'mechanizes_into'
  | 'symbolizes'
  | 'formalizes_as'
  | 'enables'
  | 'precedes'
  | 'repeats_as'
  | 'institutionalizes_as';

export interface GraphNode {
  id: string;
  label: string;
  kind: 'GEA' | 'GEM' | 'GECD' | 'GEK' | 'GEpHR' | 'carrier';
  metadata?: Record<string, unknown>;
}

export interface GraphEdge {
  source: string;
  target: string;
  type: GraphEdgeType;
  label?: string;
  metadata?: Record<string, unknown>;
}

export interface GeometryGraph {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

export interface GeometryTimeline {
  generated_at: string;
  groups: {
    by_time: Record<string, string[]>;
    by_civilization: Record<string, string[]>;
    by_element: Record<string, string[]>;
    by_molecule: Record<string, string[]>;
    by_carrier_type: Record<string, string[]>;
    by_dimension_shift: Record<string, string[]>;
    by_gek: Record<string, string[]>;
    by_gephr: Record<string, string[]>;
  };
  nodes: GECDNode[];
}

