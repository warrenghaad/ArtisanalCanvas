import { loadAllGeometryRegistries } from './loadRegistry';
import type { GECDNode, GeometryRegistries, GraphEdge } from './types';

export interface DetectedNesting {
  node_id: string;
  direct_elements: string[];
  direct_molecules: string[];
  component_geas: string[];
  component_gems: string[];
  inferred_geks: string[];
  inferred_gephrs: string[];
  dimension_shift: string;
  carrier_surface: string;
  edges: GraphEdge[];
}

function unique(values: string[]): string[] {
  return Array.from(new Set(values.filter(Boolean)));
}

export function detectNesting(gecdNode: GECDNode, registry: GeometryRegistries = loadAllGeometryRegistries()): DetectedNesting {
  const componentGeas: string[] = [];
  const componentGems: string[] = [];
  const inferredGeks: string[] = [...gecdNode.registers.function.gek_ids];
  const inferredGephrs: string[] = [...gecdNode.registers.metaphor.gephr_ids];
  const edges: GraphEdge[] = [];

  for (const moleculeId of gecdNode.molecules) {
    const molecule = registry.gemPatterns.find((item) => item.id === moleculeId);
    if (!molecule) continue;
    for (const component of molecule.components) {
      if (component.startsWith('gea.')) componentGeas.push(component);
      if (component.startsWith('gem.')) componentGems.push(component);
      edges.push({ source: component, target: moleculeId, type: 'combines_into', label: 'component of' });
    }
    inferredGeks.push(...molecule.possible_geks);
    inferredGephrs.push(...molecule.possible_gephrs);
    edges.push({ source: moleculeId, target: gecdNode.id, type: 'appears_on', label: `appears on ${gecdNode.carrier.type}` });
  }

  for (const elementId of gecdNode.elements) {
    const element = registry.idIndex.get(elementId) as any;
    inferredGeks.push(...(element?.possible_geks || []));
    inferredGephrs.push(...(element?.possible_gephrs || []));
    edges.push({ source: elementId, target: gecdNode.id, type: 'appears_on', label: `appears on ${gecdNode.carrier.type}` });
  }

  for (const target of gecdNode.nesting.contains) edges.push({ source: gecdNode.id, target, type: 'contains' });
  for (const target of gecdNode.nesting.precedes) edges.push({ source: gecdNode.id, target, type: 'precedes' });
  for (const target of gecdNode.nesting.enables) edges.push({ source: gecdNode.id, target, type: 'enables' });

  const dimensionShift = `${gecdNode.dimension.from_dimension}->${gecdNode.dimension.to_dimension}:${gecdNode.dimension.spatial_mode}`;
  if (gecdNode.dimension.to_dimension === '3D') {
    edges.push({ source: gecdNode.id, target: dimensionShift, type: 'extrudes_into', label: 'dimension shift' });
  }
  if (gecdNode.dimension.to_dimension === '4D_temporal_motion' || gecdNode.dimension.spatial_mode === 'rotation' || gecdNode.dimension.spatial_mode === 'mechanism') {
    edges.push({ source: gecdNode.id, target: dimensionShift, type: 'mechanizes_into', label: 'motion shift' });
  }

  return {
    node_id: gecdNode.id,
    direct_elements: unique(gecdNode.elements),
    direct_molecules: unique(gecdNode.molecules),
    component_geas: unique(componentGeas),
    component_gems: unique(componentGems),
    inferred_geks: unique(inferredGeks),
    inferred_gephrs: unique(inferredGephrs),
    dimension_shift: dimensionShift,
    carrier_surface: `${gecdNode.carrier.type}:${gecdNode.carrier.label}`,
    edges,
  };
}

