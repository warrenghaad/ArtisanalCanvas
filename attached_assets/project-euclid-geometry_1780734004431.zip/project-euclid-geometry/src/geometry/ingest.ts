import { composeGeometry } from './compose';
import { loadAllGeometryRegistries } from './loadRegistry';
import type { ComposeResult, GEA, GEM, GEK, GEpHR, GeometryRegistries } from './types';

export interface GeometryIngestResult {
  input: string;
  normalized: string;
  matched_ids: string[];
  matches: Array<{ id: string; label: string; kind: 'GEA' | 'GEM' | 'GEK' | 'GEpHR'; score: number }>;
  composition_candidates: ComposeResult[];
  research_queries: string[];
  design_brief: {
    day_a_metaphor_register: string[];
    day_b_function_register: string[];
    svg_hints: string[];
    prompt: string;
    filename_suggestions: string[];
  };
  next_actions: string[];
  cautions: string[];
}

function normalize(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
}

function tokens(value: string): Set<string> {
  return new Set(normalize(value).split(/\s+/).filter(Boolean));
}

function scoreNeedle(needle: string, haystacks: string[]): number {
  const n = normalize(needle);
  const nTokens = tokens(needle);
  let score = 0;
  for (const hay of haystacks) {
    const h = normalize(hay);
    if (!h) continue;
    if (h === n) score = Math.max(score, 1);
    if (h.includes(n) || n.includes(h)) score = Math.max(score, 0.8);
    const hTokens = tokens(h);
    const overlap = Array.from(nTokens).filter((token) => hTokens.has(token)).length;
    if (overlap) score = Math.max(score, overlap / Math.max(nTokens.size, hTokens.size));
  }
  return score;
}

function matchRegistry(input: string, registry: GeometryRegistries): GeometryIngestResult['matches'] {
  const candidates: GeometryIngestResult['matches'] = [];
  const geas = [...registry.geaBasic, ...registry.geaPetzinger32];
  for (const item of geas) {
    const score = scoreNeedle(input, [item.id, item.label, ...item.aliases, ...item.recognition_keywords]);
    if (score >= 0.35) candidates.push({ id: item.id, label: item.label, kind: 'GEA', score });
  }
  for (const item of registry.gemPatterns) {
    const score = scoreNeedle(input, [item.id, item.label, ...item.visual_features, ...item.formal_properties]);
    if (score >= 0.35) candidates.push({ id: item.id, label: item.label, kind: 'GEM', score });
  }
  for (const item of registry.gekConcepts) {
    const score = scoreNeedle(input, [item.id, item.label, ...item.recognition_keywords, item.definition]);
    if (score >= 0.4) candidates.push({ id: item.id, label: item.label, kind: 'GEK', score });
  }
  for (const item of registry.gephrMeanings) {
    const score = scoreNeedle(input, [item.id, item.label, item.summary, item.visual_affordance_explanation]);
    if (score >= 0.45) candidates.push({ id: item.id, label: item.label, kind: 'GEpHR', score });
  }
  return candidates.sort((a, b) => b.score - a.score || a.id.localeCompare(b.id)).slice(0, 12);
}

function getById<T>(registry: GeometryRegistries, id: string): T | undefined {
  return registry.idIndex.get(id) as T | undefined;
}

function unique(values: string[]): string[] {
  return Array.from(new Set(values.filter(Boolean)));
}

export function ingestGeometryConcept(input: string, options: { civilization?: string; carrierHint?: string } = {}, registry: GeometryRegistries = loadAllGeometryRegistries()): GeometryIngestResult {
  const civilization = options.civilization || 'Mesopotamia';
  const matches = matchRegistry(input, registry);
  const matchedIds = unique(matches.map((match) => match.id));
  const geaOrGemIds = matchedIds.filter((id) => id.startsWith('gea.') || id.startsWith('gem.'));
  const compositionCandidates = composeGeometry(geaOrGemIds, registry);

  const geaMatches = matchedIds.filter((id) => id.startsWith('gea.')).map((id) => getById<GEA>(registry, id)).filter(Boolean) as GEA[];
  const gemMatches = matchedIds.filter((id) => id.startsWith('gem.')).map((id) => getById<GEM>(registry, id)).filter(Boolean) as GEM[];
  const geks = unique([
    ...matchedIds.filter((id) => id.startsWith('gek.')),
    ...geaMatches.flatMap((item) => item.possible_geks),
    ...gemMatches.flatMap((item) => item.possible_geks),
    ...compositionCandidates.flatMap((item) => item.added_geks),
  ]).map((id) => getById<GEK>(registry, id)).filter(Boolean) as GEK[];
  const gephrs = unique([
    ...matchedIds.filter((id) => id.startsWith('gephr.')),
    ...geaMatches.flatMap((item) => item.possible_gephrs),
    ...gemMatches.flatMap((item) => item.possible_gephrs),
    ...compositionCandidates.flatMap((item) => item.possible_gephrs),
  ]).map((id) => getById<GEpHR>(registry, id)).filter(Boolean) as GEpHR[];

  const shapeLabels = unique([...geaMatches.map((item) => item.label), ...gemMatches.map((item) => item.label), ...compositionCandidates.map((item) => item.label)]).slice(0, 8);
  const researchQueries = unique([
    `${civilization} ${shapeLabels.join(' ')} geometric motif artifact`,
    `${civilization} ${input} carrier seal tablet architecture source`,
    `${input} ancient geometry symbol formal properties historical evidence`,
    `${shapeLabels[0] || input} museum catalogue ${civilization} relief seal tablet`,
    options.carrierHint ? `${civilization} ${input} ${options.carrierHint} geometric design` : '',
  ]);

  const dayA = gephrs.map((item) => `${item.id}: ${item.label}`).slice(0, 8);
  const dayB = geks.map((item) => `${item.id}: ${item.label}`).slice(0, 8);
  const svgHints = unique(geaMatches.map((item) => item.svg_hint).filter(Boolean)).slice(0, 5);
  const prompt = `Design a clean educational geometric study for "${input}". Preserve Day A metaphor labels separately from Day B function labels. Show atomic GEAs first, then any GEM compounds, then a carrier mockup. Use simple SVG-like geometry, label center/axis/repetition when relevant, and leave source placeholders for historical verification.`;
  const safeSlug = normalize(input).replace(/\s+/g, '_') || 'geometry_ingest';

  return {
    input,
    normalized: normalize(input),
    matched_ids: matchedIds,
    matches,
    composition_candidates: compositionCandidates,
    research_queries: researchQueries,
    design_brief: {
      day_a_metaphor_register: dayA,
      day_b_function_register: dayB,
      svg_hints: svgHints,
      prompt,
      filename_suggestions: [
        `src/geometry/research/${safeSlug}.research.json`,
        `src/geometry/designs/${safeSlug}.svg`,
        `src/geometry/seeds/gecd.${civilization.toLowerCase()}.${safeSlug}.json`,
      ],
    },
    next_actions: [
      'Run research queries against approved museum/catalogue/library sources.',
      'Create or update a GECD evidence node; never duplicate an equivalent carrier + element + civilization + date record.',
      'Attach verified citations before promoting the node from provisional to curriculum-ready.',
      'Generate a design study from the SVG hints and GEM composition candidates.',
    ],
    cautions: [
      'Do not claim universality without source evidence.',
      'Keep Day A metaphor-register and Day B function-register claims separate.',
      'The ingest trigger creates research/design leads; historical claims remain provisional until sourced.',
    ],
  };
}

