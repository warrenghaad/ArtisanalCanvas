# Project EUCLID Geometry Ontology Substrate

This package implements a backend-ready registry and inference substrate for geometric elements, compounds, carrier evidence nodes, concepts, metaphor registers, nesting rules, timelines, and graph export.

## Core flow

`ingestGeometryConcept("circle")` creates a research/design trigger:

1. Match shape or concept against GEA, GEM, GEK, and GEpHR registries.
2. Compose possible molecular outputs using nesting rules.
3. Produce research queries for external source lookup.
4. Produce a design brief that preserves Day A metaphor-register and Day B function-register separately.
5. Suggest file paths for research JSON, SVG/design output, and GECD seed nodes.

The code intentionally does **not** make unsourced historical claims. It gives you the hooks where museum/catalogue/library search results should be attached.

## Commands

```bash
npm run geometry:validate
npm run geometry:seed
npm run geometry:timeline
npm run geometry:graph
node dist/scripts/geometry-cli.js compose --ids gea.circle,gea.radial_line
node dist/scripts/geometry-cli.js ingest --term circle --civilization Mesopotamia
```

## Register discipline

Day A metaphor-register lives in `GEpHR` and GECD `registers.metaphor`.
Day B function-register lives in `GEK` and GECD `registers.function`.

The same form can appear in both registers, but the claims are stored separately.

