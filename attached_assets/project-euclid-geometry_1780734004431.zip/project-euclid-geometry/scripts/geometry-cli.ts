#!/usr/bin/env node
import { dirname, resolve } from 'path';
import { existsSync, mkdirSync, writeFileSync } from 'fs';
import { composeGeometry } from '../src/geometry/compose';
import { exportGraph } from '../src/geometry/exportGraph';
import { ingestGeometryConcept } from '../src/geometry/ingest';
import { loadAllGeometryRegistries } from '../src/geometry/loadRegistry';
import { buildGeometryTimeline } from '../src/geometry/timeline';

function argValue(name: string): string | undefined {
  const index = process.argv.indexOf(name);
  return index >= 0 ? process.argv[index + 1] : undefined;
}

function printUsage(): void {
  console.log(`Geometry CLI

Commands:
  validate
  seed
  compose --ids gea.circle,gea.radial_line
  ingest --term circle [--civilization Mesopotamia]
  timeline --civilization Mesopotamia
  graph --out geometry-graph.json
`);
}

function main(): void {
  const command = process.argv[2];
  if (!command || command === 'help' || command === '--help') {
    printUsage();
    return;
  }

  const registry = loadAllGeometryRegistries(process.cwd());

  if (command === 'validate') {
    console.log('Geometry registries valid.');
    console.log(JSON.stringify({
      geaBasic: registry.geaBasic.length,
      geaPetzinger32: registry.geaPetzinger32.length,
      gemPatterns: registry.gemPatterns.length,
      gekConcepts: registry.gekConcepts.length,
      gephrMeanings: registry.gephrMeanings.length,
      gecdSeedNodes: registry.gecdSeedNodes.length,
      nestingRules: registry.nestingRules.length,
    }, null, 2));
    return;
  }

  if (command === 'seed') {
    console.log(JSON.stringify(registry.gecdSeedNodes, null, 2));
    return;
  }

  if (command === 'compose') {
    const ids = (argValue('--ids') || '').split(',').map((value) => value.trim()).filter(Boolean);
    if (!ids.length) throw new Error('compose requires --ids gea.circle,gea.radial_line');
    console.log(JSON.stringify(composeGeometry(ids, registry), null, 2));
    return;
  }

  if (command === 'ingest') {
    const term = argValue('--term') || argValue('--shape') || argValue('--concept');
    if (!term) throw new Error('ingest requires --term circle');
    const civilization = argValue('--civilization') || 'Mesopotamia';
    console.log(JSON.stringify(ingestGeometryConcept(term, { civilization }, registry), null, 2));
    return;
  }

  if (command === 'timeline') {
    const civilization = argValue('--civilization');
    const nodes = civilization ? registry.gecdSeedNodes.filter((node) => node.civilization === civilization) : registry.gecdSeedNodes;
    console.log(JSON.stringify(buildGeometryTimeline(nodes), null, 2));
    return;
  }

  if (command === 'graph') {
    const out = argValue('--out') || 'geometry-graph.json';
    const graph = exportGraph(registry.gecdSeedNodes, registry);
    const outPath = resolve(process.cwd(), out);
    const folder = dirname(outPath);
    if (!existsSync(folder)) mkdirSync(folder, { recursive: true });
    writeFileSync(outPath, JSON.stringify(graph, null, 2), 'utf8');
    console.log(`Wrote ${outPath}`);
    return;
  }

  throw new Error(`Unknown command: ${command}`);
}

try {
  main();
} catch (error) {
  console.error(error instanceof Error ? error.message : String(error));
  process.exit(1);
}

